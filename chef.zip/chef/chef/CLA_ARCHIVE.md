
Corporate CLAs

The list of Corporate CLAs allowed to contribute to Opscode projects. Only contributions from approved employees of these companies are acceptable.

Employees get approved by being listed on the schedule A of the Corporate CLA.

| **Number:** | **Company:**                           | **Date:** |
|:------------|:---------------------------------------|:----------|
|  1          |  Opscode                               |           |
|  2          |  Engine Yard                           |  1/7/09   |
|  3          |  Wikia                                 |           |
|  4          |  Aptana                                |  2/12/09  |
|  5          |  CleanOffer                            |  3/2/09   |
|  6          |  37signals                             |  3/4/09   |
|  7          |  Nomitor                               |  3/9/09   |
|  8          |  We Go To 12                           |  4/30/09  |
|  9          |  Plus2 Pty                             |  5/8/09   |
|  10         |  Phusion                               |  6/22/09  |
|  11         |  Rightscale                            |  6/30/09  |
|  12         |  Rubaidh                               |  7/27/09  |
|  13         |  Peritor GmbH                          |  8/12/09  |
|  14         |  Heroku                                |  8/13/09  |
|  15         |  Internet Exchange                     |  9/22/09  |
|  16         |  Betfair                               |  9/30/09  |
|  17         |  Sojern                                |  11/2/09  |
|  18         |  Runa                                  |  12/20/09 |
|  19         |  MaxMedia                              |  1/11/10  |
|  20         |  Quantifind                            |  2/11/10  |
|  21         |  VMware                                |  2/11/10  |
|  22         |  Rackspace                             |  2/26/10  |
|  23         |  Leaway Enterprise                     |  3/16/10  |
|  24         |  Bueda                                 |  3/30/10  |
|  25         |  Divergent Logic                       |  5/3/10   |
|  26         |  Basho Technologies                    |  5/4/10   |
|  27         |  Seven Scale                           |  5/13/10  |
|  28         |  IglooNET                              |  5/21/10  |
|  29         |  Freistil Consulting                   |  5/25/10  |
|  30         |  Promet Solutions                      |  5/25/10  |
|  31         |  Mint Digital                          |  6/16/10  |
|  32         |  Picklive                              |  6/16/10  |
|  33         |  42 Lines                              |  6/27/10  |
|  34         |  Wildfire Interactiv                   |  7/9/10   |
|  35         |  Dynamic Network Services              |  7/21/10  |
|  36         |  PeerPong                              |  8/4/10   |
|  37         |  domainfactory GmbH                    |  8/16/10  |
|  38         |  Tecnh                                 |  8/17/10  |
|  39         |  9Summer                               |  9/9/10   |
|  40         |  Wixpress                              |  9/13/10  |
|  41         |  Blue Box Group                        |  9/29/10  |
|  42         |  FindsYou Limited                      |  10/6/10  |
|  43         |  Highgroove Studios                    |  10/25/10 |
|  44         |  ZeStuff                               |  10/28/10 |
|  45         |  Worlize                               |  10/28/10 |
|  46         |  Automated Labs                        |  11/3/10  |
|  47         |  Estately                              |  11/4/10  |
|  48         |  Kapoq                                 |  11/10/10 |
|  49         |  Openminds                             |  11/10/10 |
|  50         |  MobileCause                           |  11/10/10 |
|  51         |  Atalanta Systems                      |  11/14/10 |
|  52         |  Menue Americas                        |  11/17/10 |
|  53         |  Sociable Limited                      |  12/1/10  |
|  54         |  Nine Summer                           |  12/6/10  |
|  55         |  Neo Technology                        |  1/27/11  |
|  56         |  Moriz GmbH                            |  2/2/11   |
|  57         |  AegisCo                               |  2/14/11  |
|  58         |  SetJam                                |  2/15/11  |
|  59         |  Tippr                                 |  2/18/11  |
|  60         |  Ning                                  |  2/24/11  |
|  61         |  Workday                               |  3/12/11  |
|  62         |  7digital                              |  3/3/11   |
|  63         |  PagerDuty                             |  3/17/11  |
|  64         |  Gnowsis                               |  3/25/11  |
|  65         |  Unboxed Consulting                    |  4/1/11   |
|  66         |  CustomInk                             |  4/8/11   |
|  67         |  TalentBox                             |  4/25/11  |
|  68         |  Wavii                                 |  4/29/11  |
|  69         |  Datadog                               |  5/4/11   |
|  70         |  Viximo                                |  5/10/11  |
|  71         |  ZephirWorks                           |  5/11/11  |
|  72         |  Dell                                  |  5/12/11  |
|  73         |  Newsweek/Daily Beast Company          |  5/19/11  |
|  74         |  WordStream                            |  5/19/11  |
|  75         |  Flagbit                               |  6/14/11  |
|  76         |  Applications Online                   |  6/17/11  |
|  77         |  Versapay                              |  7/5/11   |
|  78         |  DigiTar                               |  7/19/11  |
|  79         |  DreamHost                             |  7/21/11  |
|  80         |  Edmunds.com                           |  7/22/11  |
|  81         |  Every Ware                            |  7/25/11  |
|  82         |  Ask.com                               |  8/1/11   |
|  83         |  bring.out doo Sarajevo                |  8/11/11  |
|  84         |  Kos Media                             |  8/15/11  |
|  85         |  reallyenglish.com                     |  8/15/11  |
|  86         |  Fewbytes                              |  8/18/11  |
|  87         |  Business Intelligence Associates      |  8/19/11  |
|  88         |  Tacit Knowledge                       |  8/22/11  |
|  89         |  Zenexity                              |  8/30/11  |
|  90         |  ClassDo                               |  8/30/11  |
|  91         |  Myplanet                              |  9/2/11   |
|  92         |  ihiji                                 |  9/16/11  |
|  93         |  "Port 80 Productions, LLC"            |  10/28/11 |
|  94         |  Green Alto                            |  11/2/11  |
|  95         |  "Heavy Water Software, Inc."          |  11/4/11  |
|  96         |  Wealthfront Inc.                      |  11/15/11 |
|  97         |  "Kickstarter, Inc."                   |  11/18/11 |
|  98         |  Webtrends Inc                         |  11/22/11 |
|  99         |  "Infochimps, Inc."                    |  11/28/11 |
|  100        |  "Cycle Computing, LLC"                |  11/29/11 |
|  101        |  "Ubalo, Inc"                          |  12/8/11  |
|  102        |  "SweetSpot Diabetes Care, Inc."       |  12/12/11 |
|  103        |  "RideCharge, Inc."                    |  12/15/11 |
|  104        |  "Riot Games, Inc."                    |  12/15/11 |
|  105        |  Fiksu                                 |  12/21/11 |
|  106        |  WhitePages Inc.                       |  1/3/12   |
|  107        |  "CX, Inc."                            |  1/12/12  |
|  108        |  Spoke Software                        |  1/15/12  |
|  109        |  Xforty Technologies                   |  1/25/12  |
|  110        |  "Democracy Works, Inc"                |  1/30/12  |
|  111        |  "Pure Lake Software, Inc."            |  2/10/12  |
|  112        |  Sveriges Television AB                |  2/14/12  |
|  113        |  Reaktor Innovations                   |  2/14/12  |
|  114        |  "Oxygen Cloud, Inc."                  |  2/14/12  |
|  115        |  Robojar Pty Ltd                       |  2/17/12  |
|  116        |  Green and Secure IT Limited           |  2/19/12  |
|  117        |  ModCloth                              |  2/23/12  |
|  118        |  Joyent                                |  2/29/12  |
|  119        |  "Wallrazor, Inc."                     |  3/4/12   |
|  120        |  "Cerner Innovation, Inc."             |  3/8/12   |
|  121        |  "Numenta, Inc."                       |  3/27/12  |
|  122        |  Kotiri Software Ltd.                  |  4/3/12   |
|  123        |  "The Frontside Software, Inc."        |  4/5/12   |
|  124        |  "Needle, Inc."                        |  4/5/12   |
|  125        |  "Gap, Inc."                           |  4/10/12  |
|  126        |  Youscribe                             |  4/11/12  |
|  127        |  Deutsche Telekom Laboratories         |  4/17/12  |
|  128        |  "Relevance, Inc."                     |  4/20/12  |
|  129        |  Truer Sound LLC                       |  4/20/12  |
|  130        |  Websym Technologies Private Ltd.      |  4/30/12  |
|  131        |  DreamBox Learning Inc                 |  5/3/12   |
|  132        |  Simple                                |  5/7/12   |
|  133        |  "Consumer Club, Inc"                  |  5/10/12  |
|  134        |  Onddo Labs                            |  5/18/12  |
|  135        |  CyberAgent Corp.                      |  5/22/12  |
|  136        |  SourceIndex IT-Services               |  6/7/12   |
|  137        |  "Scribd, Inc."                        |  6/15/12  |
|  138        |  Civolution BV                         |  6/18/12  |
|  139        |  Drillinginfo                          |  6/18/12  |
|  140        |  NaviNet                               |  6/20/12  |
|  141        |  "Voxel Dot Net, Inc"                  |  6/26/12  |
|  142        |  Asbury Theological Seminary           |  6/27/12  |
|  143        |  The Cloudscaling Group                |  6/27/12  |
|  144        |  "Creationline, Inc."                  |  6/27/12  |
|  145        |  "Action Verb, LLC"                    |  7/10/12  |
|  146        |  Iugu Servicos na Internet LTDA        |  7/11/12  |
|  147        |  OpeniT                                |  7/18/12  |
|  148        |  Cloudreach Limited                    |  7/24/12  |
|  149        |  Bonnier Corporation                   |  7/25/12  |
|  150        |  "OneHealth Solutions, Inc."           |  7/25/12  |
|  151        |  Hewlett-Packard                       |  7/26/12  |
|  152        |  Paydici Corp.                         |  7/26/12  |
|  153        |  "Novell, Inc."                        |  8/1/12   |
|  154        |  Schuberg Phillis B.V.                 |  8/3/12   |
|  155        |  RelatelIQ Inc.                        |  8/3/12   |
|  156        |  HomeMade Digital Ltd                  |  8/7/12   |
|  157        |  "PrimeRevenue, Inc"                   |  8/10/12  |
|  158        |  Calxeda                               |  8/14/12  |
|  159        |  Big Cartel LLC                        |  8/17/12  |
|  160        |  Atlassian                             |  8/27/12  |
|  161        |  One Connect Limited                   |  9/7/12   |
|  162        |  Sonian Inc                            |  9/8/12   |
|  163        |  The App Business                      |  9/19/12  |
|  164        |  "Pat Deegan, PhD & Associates, LLC"   |  9/26/12  |
|  165        |  OmniTI                                |  9/26/12  |
|  166        |  "Cloudant, Inc."                      |  10/5/12  |
|  167        |  ZestFinance                           |  10/8/12  |
|  168        |  Firebelly Design                      |  10/8/12  |
|  169        |  Nu Echo                               |  10/16/12 |
|  170        |  OpenConcept Consulting Inc.           |  10/18/12 |
|  171        |  Apptentive                            |  10/20/12 |
|  172        |  "Document Swarm, LLC"                 |  10/20/12 |
|  173        |  "Tilting @, LLC"                      |  10/29/12 |
|  174        |  "Sift Science, Inc"                   |  10/31/12 |
|  175        |  FluxSauce                             |  11/1/12  |
|  176        |  Rocket Internet GmbH                  |  11/2/12  |
|  177        |  Coding-Knight LTD                     |  11/6/12  |
|  178        |  Tapp                                  |  11/13/12 |
|  179        |  Taqtiqa LLC                           |  11/14/12 |
|  180        |  "Nordstrom, Inc"                      |  11/15/12 |
|  181        |  Daptiv Solutions LLC                  |  11/26/12 |
|  182        |  Lime Pepper Ltd                       |  11/28/12 |
|  183        |  "Straydog Software, Inc."             |  11/29/12 |
|  184        |  "Fidelity Technology Group, LLC"      |  12/6/12  |
|  185        |  "Angelweb, Unipessoal Lda."           |  12/14/12 |
|  186        |  bcs kommunikationslosungen            |  12/17/12 |
|  187        |  "North County Tech Center, LLC"       |  12/22/12 |
|  188        |  Emergent One                          |  1/9/13   |
|  189        |  Ninefold Pty Limited                  |  1/9/13   |
|  190        |  DecisionDesk                          |  1/13/13  |
|  191        |  Belly Inc                             |  1/15/13  |
|  192        |  cloudbau Gmbh                         |  1/18/13  |
|  193        |  ActBlue Technical Services            |  1/18/13  |
|  194        |  HiganWorks LLC                        |  1/22/13  |
|  195        |  Ontario Systems                       |  1/23/13  |
|  196        |  "Lytro, Inc."                         |  1/23/13  |
|  197        |  Grupa Allegro Sp. z o.o.              |  1/31/13  |
|  198        |  Workday Inc.                          |  2/5/13   |
|  199        |  "Atlas Digital, LLC"                  |  2/6/13   |
|  200        |  Intoximeters                          |  2/15/13  |
|  201        |  Airbnb                                |  2/17/13  |
|  202        |  Valtech AB                            |  2/20/13  |
|  203        |  AWeber Communications                 |  2/25/13  |
|  204        |  adesso mobile solutions GmbH          |  3/4/13   |
|  205        |  "Banno, LLC"                          |  3/5/13   |
|  206        |  AboutUs                               |  3/8/13   |
|  207        |  "Google, Inc"                         |  3/14/13  |
|  208        |  cloudControl GmbH                     |  3/21/13  |
|  209        |  Springest                             |  3/25/13  |
|  210        |  Criteo                                |  3/26/13  |
|  211        |  "Thinking Phone Networks, Inc."       |  4/8/13   |
|  212        |  Evolving Web Inc                      |  4/11/13  |
|  213        |  BinaryBabel OSS                       |  4/17/13  |
|  214        |  Tout Industries                       |  4/18/13  |
|  215        |  "Lookout, Inc."                       |  4/22/13  |
|  216        |  Recorded Future Inc                   |  4/23/13  |
|  217        |  Irrational Industries                 |  5/1/13   |
|  218        |  "Socrata, Inc"                        |  5/1/13   |
|  219        |  "Aspera, Inc"                         |  5/1/13   |
|  220        |  "Hadapt, Inc"                         |  5/3/13   |
|  221        |  Moncai                                |  5/7/13   |
|  222        |  IBM                                   |  5/14/13  |
|  223        |  Yahoo Inc.                            |  5/14/13  |
|  224        |  Texas A&M University College of Arch. |  5/20/13  |
|  225        |  MoPub                                 |  5/21/13  |
|  226        |  "Onelogin, Inc"                       |  5/24/13  |
|  227        |  Yola                                  |  5/28/13  |
|  228        |  CopperEgg                             |  5/28/13  |
|  229        |  "MeetMe, Inc"                         |  5/30/13  |
|  230        |  Boadree Innovations Kft.              |  6/17/13  |
|  231        |  "Bitium, inc"                         |  6/21/13  |
|  232        |  Heart of Sales LLC DBA Ace of Sales   |  7/4/13   |
|  233        |  NetSrv Consulting Ltd                 |  7/7/13   |
|  234        |  "AURIN Project"                       |  7/11/13  |
|  235        |  Onlife Health Inc                     |  7/17/13  |
|  236        |  Roblox Inc.                           |  7/17/13  |
|  237        |  "Taos Mountain, Inc"                  |  7/24/13  |
|  238        |  CoreMedia AG                          |  7/31/13  |
|  239        |  "PROS, Inc. a Delaware Corporation"   |  8/14/13  |
|  240        |  Identive Group                        |  8/21/13  |
|  241        |  University of Derby                   |  8/22/13  |
|  242        |  TeamSnap                              |  8/29/13  |
|  243        |  Social Ally Pty Ltd                   |  8/29/13  |
|  244        |  Ecodev Sarl                           |  9/9/13   |
|  245        |  kreuzwerker GmbH                      |  9/18/13  |
|  246        |  Central Desktop                       |  9/18/13  |
|  247        |  Siili Solutions                       |  9/19/13  |
|  248        |  Twiket LTD                            |  9/23/13  |
|  249        |  Cloudsoft                             |  9/25/13  |
|  250        |  MYOB NZ Limited                       |  9/26/13  |
|  251        |  Mollie B.V.                           |  9/30/13  |
|  252        |  Unbounce                              |  10/1/13  |
|  253        |  Shutl Ltd.                            |  10/2/13  |
|  254        |  Rapid7                                |  10/7/13  |
|  255        |  "Our Film Festival, Inc (dba Fandor)" |  10/7/13  |
|  256        |  "Ooyala, Inc."                        |  10/9/13  |
|  257        |  Squaremouth Inc                       |  10/10/13 |
|  258        |  Optiflows                             |  10/11/13 |
|  259        |  General Sensing LTD                   |  10/10/13 |
|  260        |  Deployable LTD                        |  10/22/13 |
|  261        |  Klarna                                |  10/23/13 |
|  262        |  "Nike, Inc."                          |  10/25/13 |
|  263        |  SoundCloud Ltd.                       |  11/5/13  |
|  264        |  Project Florida                       |  11/5/13  |
|  265        |  Intuit                                |  11/6/13  |
|  266        |  ComputeNext                           |  11/6/13  |
|  267        |  The Weather Companies                 |  11/8/13  |
|  268        |  PTC Inc                               |  11/13/13 |
|  269        |  RamTank Inc                           |  11/19/13 |
|  270        |  GoCardless                            |  11/24/13 |
|  271        |  ZANOX AG                              |  11/30/13 |
|  272        |  ARINC                                 |  12/3/13  |
|  273        |  Lockheed Martin Corporation           |  12/3/13  |
|  274        |  Brightcove                            |  12/16/13 |
|  275        |  "Sprint.ly, Inc"                      |  12/27/13 |
|  276        |  Cramer Development                    |  1/10/14  |
|  277        |  "BlackBerry, Inc."                    |  1/20/14  |
|  278        |  Cerner Innovation Inc                 |  2/6/14   |
|  279        |  Cerner Innovation Inc                 |  2/11/14  |
|  280        |  Engine Yard                           |  2/12/14  |
|  281        |  Crux Hosted Services                  |  2/18/14  |
|  282        |  Blue Spurs                            |  2/24/14  |
|  283        |  GitLab.com                            |  3/1/14   |
|  284        |  Yelp                                  |  3/7/14   |
|  285        |  Workday                               |  3/10/14  |
|  286        |  BMC Software Inc                      |  3/13/14  |
|  287        |  Itison                                |  3/14/14  |
|  288        |  "OnBeep, Inc."                        |  3/19/14  |
|  289        |  Level 11 Consulting                   |  3/19/14  |
|  290        |  Linaro Limited                        |  4/4/14   |
|  291        |  Spanlink Communications               |  4/17/14  |
|  292        |  "WESEEK, Inc"                         |  4/29/14  |
|  293        |  "Iniqa UK, Ltd"                       |  6/4/14   | 
|  294        |  Jemstep                               |  6/13/1   |




Allowed Contributors

The list of allowed contributors to Opscode projects. Persons listed as associated with a company may also be individual contributors as well.

To get on the list, check out our instructions on how to contribute.

1.  Adam Jacob 	 Opscode 	
1.  Andy Delcambre 	 Engineyard 	1/7/09
1.  Arjuna Christensen 	 	1/7/09
1.  Artur Bergman 	 Wikia 	
1.  Benjamin Black 	 Opscode 	1/10/09 	
1.  Bryan McLellan 	 	1/7/09 	
1.  Dan Walters 	 	3/7/09
1.  Edward Muller 	 Engineyard 	1/28/09
1.  Ezra Zygmuntowicz 	 Engineyard 	1/7/09
1.  Jason Cook 	 Wikia 	
1.  Joe Williams 	 	1/17/09
1.  Kris Rasmussen 	 Aptana 	2/12/09
1.  Lee Jensen 	 Engineyard 	1/24/09
1.  Nick Sullivan 	 Wikia 	
1.  Paul Nasrat 	 	1/19/09
1.  Pawel Rein 	 Wikia 	
1.  Przemek Malkowski 	 Wikia 	
1.  Sean Cribbs 	 	2/5/09
1.  Steve Berryman 	 	1/20/09
1.  Steven Parkes 	 Aptana 	2/12/09
1.  Thom May 	 	1/21/09
1.  Tim Dysinger 	 	1/28/09
1.  Michael Hale 	 	2/16/09
1.  Mathieu Sauve-Frankel 	 	2/22/09
1.  Matthew Landauer 	 	2/25/09
1.  John Hampton 	 CleanOffer 	3/2/09
1.  Nadeem Bitar 	 CleanOffer 	3/2/09
1.  James Gartrell 	 	2/6/09
1.  Joshua Sierles 	 37signals 	3/4/09
1.  Mark Imbriaco 	 37signals 	3/4/09
1.  Stephen Haynes 	 Nomitor 	3/9/09
1.  Yun Huang Yong 	 Nomitor 	3/9/09
1.  David Lee 	 	3/9/09
1.  Matthew Kent 	 	3/24/09
1.  Dave Myron 	 	4/3/09
1.  Miguel Cabeça 	 	8/4/09
1.  Jason Jackson 	 	4/9/09
1.  Caleb Tennis 	 	4/10/09
1.  Michael Lim 	 	4/14/09
1.  David Balatero 	 	4/28/09
1.  David Grandinetti 	 We Go To 12 	4/30/09
1.  Lachlan Cox 	 Plus2 Pty 	5/8/09
1.  Scott Likens 	 	4/30/09
1.  Andrew Willis 	 	5/25/09
1.  Hongli Lai 	 Phusion 	6/22/09
1.  Ninh Bui 	 Phusion 	6/22/09
1.  Edmund Haselwanter	cloudbau Gmbh	6/25/09
1.  Raphael Simon 	 RightScale 	6/30/09
1.  Tony Spataro 	 RightScale 	6/30/09
1.  Stéphane Crivisier 	 	6/30/09
1.  Matthew Todd 	 Highgroove Studios 	7/1/09
1.  Grant Zanetti 	 	2/1/09
1.  Peter Woodman 	 	6/22/09
1.  Daniel DeLeo 	 	7/10/09
1.  Jeppe Madsen 	 	9/13/09
1.  Cary Penniman 	 RightScale 	7/20/09
1.  J. Chris Anderson 	 	8/7/09
1.  Graeme Mathieson 	 Rubaidh 	8/10/09
1.  Mark Connell 	 Rubaidh 	8/10/09
1.  Jonathan Weiss 	 Peritor GmbH 	8/12/09
1.  Mathias Meyer 	 Peritor GmbH 	8/12/09
1.  Pedro Belo 	 Heroku 	8/13/09
1.  Ricardo Chimal Jr. 	 Heroku 	8/13/09
1.  Adam Wiggins 	 Heroku 	8/13/09
1.  Ryan Tomayko 	 Heroku 	8/13/09
1.  Blake Mizerany 	 Heroku 	8/13/09
1.  Diego Algorta 	 	
1.  Kevin Hunt 	 	8/14/09 	
1.  Sidney Burks 	 	8/20/09 	
1.  Joe Van Dyk 	 	9/1/09 	
1.  Sig Lange 	 	9/1/09 	
1.  Alexander van Zoest 	 	9/1/09 	
1.  Nathan Mueller 	 	9/7/09 	
1.  Roman Heinrich 	 	9/11/09 	
1.  Gábor Vészi 	 	9/20/09 	
1.  Kenneth Kalmer 	 Internet Exchange 	9/22/09 	
1.  Luca Greco 	 	9/22/09 	
1.  Charles Cook 	 Betfair 	9/30/09 	
1.  Mario Giammarco 	 	10/6/09 	
1.  Matthew King 	 	10/14/09 	
1.  James Golick 	 	10/27/09 	
1.  Jörn Berrisch 	 	10/28/09 	
1.  Peter Crossley 	 	10/30/09 	
1.  Eric Hankins 	 Sojern 	11/2/09 	
1.  David McRae 	 Sojern 	11/2/09 	
1.  Dan Fitch 	 Sojern 	11/2/09 	
1.  Ian Meyer 	 	11/8/09 	
1.  John Alberts 	 	11/9/09 	
1.  Lee Marlow 	 	11/11/09 	
1.  Tollef Fog Heen 	 	11/12/09 	
1.  Cuong Chi Nghiem 	 	11/13/09 	
1.  Gordon Thiesfeld 	 	11/18/09 	
1.  Dreamcat4 	 	11/21/09 	
1.  Guy Bolton King 	 	12/3/09 	
1.  Robert Berger 	 Runa 	12/20/09 	
1.  Siva Jagadeesan 	 Runa 	12/20/09 	
1.  Ivan Pirlik 	 	12/22/09 	
1.  David Abdemoulaie 	 	12/23/09 	
1.  Alex Soto 	 	12/29/09 	
1.  Bryan Helmkamp 	 	12/30/09 	
1.  Jesse Nelson 	 	1/6/10 	
1.  Seth Chisamore 	 Opscode 	1/11/10 	
1.  Alfredo Deza 	 MaxMedia 	1/11/10 	
1.  N. Alan Johnson Jr. 	 	1/15/10 	
1.  Pavel Valodzka 	 	2/8/10 	
1.  Kyle Maxwell 	 Quantifind 	2/11/10 	
1.  Doug MacEachern 	 VMware 	2/11/10 	
1.  Jan Zimmek 	 	2/14/10 	
1.  Dan Prince 	 Rackspace 	2/26/10 	
1.  Gabe Westmaas 	 Rackspace 	2/26/10 	
1.  Tim Harper 	 	3/8/10 	
1.  Renaud Chaput 	 	3/10/10 	
1.  Daniel Peterson 	 	3/11/10 	
1.  Amit Cohen 	 Leaway Enterprise 	3/16/10 	
1.  Avishai Ish-Shalom 	 Leaway Enterprise 	3/16/10 	
1.  Or Cohen 	 Leaway Enterprise 	3/16/10 	
1.  Jon Swope 	 	3/19/10 	
1.  Jonathan Tron 	 	3/19/10 	
1.  Christopher Peplin 	 Bueda 	3/30/10 	
1.  Trotter Cashion 	 	4/3/10 	
1.  Benjamin Standefer 	 	4/6/10 	
1.  P. Barrett Little 	 	4/7/10 	
1.  John Nixon 	 	4/13/10 	
1.  Bruce Krysiak 	 	4/13/10 	
1.  Akzhan Abdulin 	 	4/14/10 	
1.  Grant Rodgers 	 	4/17/10 	
1.  Wesley Beary 	 	4/22/10 	
1.  Farzad Farid 	 	4/23/10 	
1.  Olivier Raginel 	 	4/26/10 	
1.  Jacques Crocker 	 	5/3/10 	
1.  Pierre Baillet 	 	5/3/10 	
1.  Joel Merrick 	 	5/3/10 	
1.  James Sanders 	 	5/3/10 	
1.  John Goulah 	 	5/3/10 	
1.  Toomas Pelberg 	 	5/3/10 	
1.  Ceaser Larry 	 Divergent Logic 	5/3/10 	
1.  Justin Sheehy 	 Basho Technologies 	5/4/10 	
1.  Andrew Gross 	 Basho Technologies 	5/4/10 	
1.  Bryan Fink 	 Basho Technologies 	5/4/10 	
1.  Ben Mabey 	 	5/5/10 	
1.  Christopher Durtschi 	 Divergent Logic 	5/7/10 	
1.  Kevin Carter 	 Divergent Logic 	5/7/10 	
1.  Saimon Moore 	 	5/13/10 	
1.  Troy Davis 	 Seven Scale 	5/13/10 	 	
1.  Eric Lindvall 	 Seven Scale 	5/13/10 	
1.  Alexey Ivanov		5/14/10 	
1.  Pritesh Mehta 	 	5/19/10 	
1.  Ondrej Kudlik 	 IglooNET 	5/21/10 	
1.  Marek Hulan 	 IglooNET 	5/21/10 	
1.  Chad Woolley 	 	5/22/10 	
1.  Jochen Lillich 	 Freistil Consulting 	5/25/10 	
1.  Marius Ducea 	 Promet Solutions 	5/25/10 	
1.  Eric Butler 	 	5/26/10 	
1.  Sahil Cooner 	 	6/6/10 	
1.  Richard Nicholas 	 Betfair 	6/9/10 	
1.  Dan Slimmon 	 	6/10/10 	
1.  Craig Webster 	 Picklive 	6/16/10 	
1.  Dean Strelau 	 Mint Digital 	6/17/10 	
1.  Kurt Yoder 	 	6/25/10 	
1.  Jim Browne 	 42 Lines 	6/27/10 	
1.  Andrey Sibiryov 	 	7/7/10 	
1.  Anthony Newman 	 Betfair 	7/8/10 	
1.  Thomas Hoover 	 	7/8/10 	
1.  Dylan Egan 	 Wildfire Interactive 	7/9/10 	
1.  Michael Carruthers 	 Wildfire Interactive 	7/11/10 	
1.  Jon Seaberg 	 RightScale 	7/20/10 	
1.  Sean O'Meara 	 	7/20/10 	
1.  Cory von Wallenstein 	 Dynamic Network Services 	7/21/10 	
1.  Michael Leinartas 	 	7/22/10 	
1.  Thomas Bishop 	 	7/23/10 	
1.  Jon Wood 	 	7/29/10 	
1.  Dmitry Vyal 	 	8/4/10 	
1.  Gilles Devaux 	 PeerPong 	8/4/10 	
1.  Chris Pepper 	 	8/5/10 	
1.  Dennis Klein 	 	8/6/10 	
1.  Warwick Poole 	 	8/12/10 	
1.  Ken Ming Ong 	 	8/15/10 	
1.  Ash Berlin 	 	8/16/10 	
1.  Jochen Tuchbreiter 	 domainfactory GmbH 	8/16/10 	
1.  Mat Ellis 	 Tecnh 	8/17/10 	
1.  Michael MacDonald 	 	8/17/10 	
1.  Jorge Luiz deBrito Falcão 	 	8/18/10 	
1.  Jamie Winsor 	 	8/19/10 	
1.  Darrin Eden 	 	8/19/10 	
1.  Jonathan Smith 	 	8/19/10 	
1.  Andrew Fulcher 	 	8/23/10 	
1.  Matthias Marschall 	 	8/25/10 	
1.  Peter Struijk 	 	8/25/10 	
1.  Robert Anthony Postill 	 	8/28/10 	
1.  Joshua Timberman 	 Opscode 	9/6/10 	
1.  Benjamin Rockwood 	 	9/6/10 	
1.  Douglas Knight 	 	9/9/10 	
1.  Andrew Cole 	 9Summer 	9/9/10 	
1.  Dimitri Krassovski 	 Wixpress 	9/13/10 	
1.  Gregory Man 	 Wixpress 	9/13/10 	
1.  Allan Feid 	 	9/17/10 	
1.  Ringo De Smet 	 	9/26/10 	
1.  Tomasz Napierala 	 	9/27/10 	
1.  Jesse Proudman 	 Blue Box Group 	9/29/10 	
1.  Ian Parades 	 Blue Box Group 	9/29/10 	
1.  Lee Huffman 	 Blue Box Group 	9/29/10 	
1.  Christopher Horton 	 	10/1/10 	
1.  Jude Sutton 	 FindsYou Limited 	10/6/10 	
1.  James Le Cuirot 	 FindsYou Limited 	10/6/10 	
1.  Richard Pelavin 	 	10/7/10 	
1.  Blake Irvin 	ModCloth	10/8/10 	
1.  Jim Van Fleet 	 	10/14/10 	
1.  Laurent Désarmes 	 	10/14/10 	
1.  Jay T. McCanta 	 	10/15/10 	
1.  Eric G. Wolfe 	 	10/20/10 	
1.  Sami Haahtinen 	 	10/21/10 	
1.  Chris Kelly 	 Highgroove Studios 	10/25/10 	
1.  Gerald L. Hevener Jr. 	 	10/25/10 	
1.  Charles Quinn 	 Highgroove Studios 	10/25/10 	
1.  Jonathan Wallace 	 Highgroove Studios 	10/25/10 	
1.  Jason Ardell 	 	10/26/10 	
1.  Sean Carey 	 	10/27/10 	
1.  Pierre-Luc Brunet 	 ZeStuff 	10/28/10 	
1.  Sean Walbran 	 	10/28/10 	
1.  Brian McKelvey 	 Worlize 	10/28/10 	
1.  Jeffrey Hulten 	 Automated Labs 	11/3/10 	
1.  Doug Cole 	 Estately 	11/4/10 	
1.  Ben Bleything 	 Estately 	11/4/10 	
1.  Sebastian Boehm 	 	11/6/10 	
1.  Ches Martin 	 	11/8/10 	
1.  Eric C. Herot 	 	11/8/10 	
1.  Oliver Hankeln 	 	11/10/10 	
1.  David Nolan 	 Kapoq 	11/10/10 	
1.  Frank Louwers 	 Openminds 	11/10/10 	
1.  Bernard Grymonpon 	 Openminds 	11/10/10 	
1.  Bram Gillemon 	 Openminds 	11/10/10 	
1.  Paul Cortens 	 MobileCause 	11/10/10 	
1.  Austin Schneider 	 MobileCause 	11/10/10 	
1.  Kevin Ahrens 	 	11/13/10 	
1.  Stephen Nelson-Smith 	 Atalanta Systems 	11/14/10 	
1.  Caleb Groom 	 	11/16/10 	
1.  Michael Ivey 		11/17/10 	
1.  Wojciech Wnetrzak 	 	11/20/10 	
1.  Dmitriy Tkachenko 	 	11/22/10 	
1.  Filip Tepper 	 	11/24/10 	
1.  Denis Barushev 	 	11/27/10 	
1.  Pedro F. <<pancho>> Horrillo Guerra	 	11/28/10 	
1.  James Harton 	 Sociable Limited 	12/1/10 	
1.  Noah Kantrowitz 	 	12/4/10 	
1.  Anthony Burton 	 	12/4/10 	
1.  David Esposito 	 Nine Summer 	12/6/10 	
1.  Mike Lecza 	 Nine Summer 	12/6/10 	
1.  Andrew Cole 	 Nine Summer 	12/6/10 	
1.  Michael Winser 	 Nine Summer 	12/6/10 	
1.  Cory Burke 	 Nine Summer 	12/6/10 	
1.  Charles Duffy 	 Tippr 	12/7/10 	
1.  John Vincent 	 	12/10/10 	
1.  Dustin Currie 	 	12/14/10 	
1.  Mark Sonnabaum 	 	12/14/10 	
1.  Elliot Murphy 	 	12/22/10 	
1.  Laradji Nacer 	 	12/30/10 	
1.  Todd Nine 	 	1/3/11 	
1.  Elijah Wright 	 	1/5/11 	
1.  Anshul Khandelwal 	 	1/13/11 	
1.  Michael Carruthers 	 	1/16/11 	
1.  Vishvananda Ishaya 	 	1/17/11 	
1.  Scott Frazer 	 	1/17/11 	
1.  Eric Hodel 	 	1/21/11 	
1.  Eric Heydrick 	 	1/25/11 	
1.  Andreas Kollegger 	 Neo Technology 	1/27/11 	
1.  Steve Lum 	 	1/31/11 	
1.  Anthony Goddard 	 	2/1/11 	
1.  Roland Moriz 	 Moriz GmbH 	2/2/11 	
1.  Emil Sit 	 Hadapt 	2/2/11 	
1.  Ranjib Dey 	 	2/3/11 	
1.  Ryan Davis 	 	2/8/11 	
1.  Eric Coleman 	 	2/8/11 	
1.  James Casey 	 	2/9/11 	
1.  Maciej Pasternacki 	 	2/9/11 	
1.  Grzegorz Marszalek 	 	2/11/11 	
1.  James Sulinski 	 AegisCo 	2/14/11 	
1.  Erik Sabowski 	 AegisCo 	2/14/11 	
1.  Maciej Pasternacki 	 SetJam 	2/15/11 	
1.  Steven Dossett 	 Ning 	2/17/11 	
1.  Dane Knecht 	 Tippr 	2/18/11 	
1.  Mark Imbriaco 	 Heroku 	2/28/11 	
1.  Jonathan Matthews	7digital	3/3/11 	
1.  Patrick Collins 	 	3/7/11 	
1.  Jim Hopp 	 Workday 	3/12/11 	
1.  Ken Dove 	 Workday 	3/12/11 	
1.  Philip Reynolds 	 Workday 	3/12/11 	
1.  Victor Zakharyev 	 Workday 	3/12/11 	
1.  Greg Fuller 	 Workday 	3/12/11 	
1.  Michael Callahan 	 Workday 	3/15/11 	
1.  Don Norton 	 Workday 	3/15/11 	
1.  Joe Nuspl 	 Workday 	3/15/11 	
1.  Dan Thom 	 Workday 	3/15/11 	
1.  Rick Cooper 	 Workday 	3/15/11 	
1.  Patrick Debois 	 	3/14/11 	
1.  Michael Guterl 	 	3/15/11 	
1.  Andrew Miklas 	 PagerDuty 	3/17/11 	
1.  Tristan Sloughter 	 	3/22/11 	
1.  Jonathon Ramsey 	 	3/23/11 	
1.  Jesai Langenbach 	 	3/24/11 	
1.  Maciej Pasternacki 	 Gnowsis 	3/25/11 	
1.  Omri Cohen 	 	3/28/11 	
1.  Joseph Sokol-Margolis 	 	3/31/11 	
1.  Alex Tomlins 	 Unboxed Consulting 	4/1/11 	
1.  Holger Just 	 	4/5/11 	
1.  Jake Vanderdray 	 CustomInk 	4/8/11 	
1.  Nathen Harvey 	 CustomInk 	4/8/11 	
1.  Padraig O'Sullivan 	 	4/8/11 	
1.  Christian Trabold 	 	4/16/11 	
1.  KC Braunschweig 	Edmunds.com	4/19/11 	
1.  Josh Pasqualetto 	 	4/21/11 	
1.  Christopher C. Johnson 	 	4/21/11 	
1.  Christian Paredes 	 	4/22/11 	
1.  Viral Shah 	 	4/24/11 	
1.  Bradley Fritz 	 	4/24/11 	
1.  Nat Lownes 	 	4/25/11 	
1.  Jonathan Tron 	 TalentBox 	4/25/11 	
1.  Joseph Halter 	 TalentBox 	4/25/11 	
1.  Wilson Felipe Nunes Fernandes Pereira		4/27/11 	
1.  Michael Grubb		4/27/11 	
1.  Brandon Konkle		4/28/11 	
1.  Matt Griffin		4/28/11 	
1.  Anh K. Huynh		4/28/11 	
1.  Erik Frey	Wavii	4/29/11 	
1.  Spike Gronim	Wavii	4/29/11 	
1.  Ian MacLeod	Wavii	4/29/11 	
1.  Guido Bartolucci	Wavii	4/29/11 	
1.  Fletcher Nichol		5/3/11 	
1.  James Kane	7digital	5/4/11 	
1.  Paul Richards	7digital	5/4/11 	
1.  Alexis Le-Quoc	Datadog	5/4/11 	
1.  Matthew Singleton	Datadog	5/4/11 	
1.  Carlo Cabanilla	Datadog	5/4/11 	
1.  Olivier Pomel	Datadog	5/4/11 	
1.  Fabrice Ollivier	Datadog	5/4/11 	
1.  Matt Griffin	Viximo	5/10/11 	
1.  Chris Chiodo	Viximo	5/10/11 	
1.  Adam Bell	Viximo	5/10/11 	
1.  Sergio Rubio		5/10/11 	
1.  Elmer Rivera		5/10/11 	
1.  Andrea Campi	ZephirWorks	5/11/11 	
1.  Andrea Carlo Granata	ZephirWorks	5/11/11 	
1.  Marco Pierleoni	ZephirWorks	5/11/11 	
1.  Pietro Giorgianni	ZephirWorks	5/11/11 	
1.  Jesse Newland		5/11/11 	
1.  Greg Swallow		5/12/11 	
1.  Scott Jensen	Dell	5/12/11 	
1.  Greg Althaus	Dell	5/12/11 	
1.  Andi Abes	Dell	5/12/11 	
1.  Rob Hirschfeld	Dell	5/12/11 	
1.  Paul Webster	Dell	5/12/11 	
1.  Mitchell Hashimoto		5/12/11 	
1.  Jamie van Dyke		5/17/11 	
1.  Vladimir Kozhukalov		5/18/11 	
1.  Nathan Butler	Newsweek/Daily Beast Company	5/19/11 	
1.  Ken Garland	Newsweek/Daily Beast Company	5/19/11 	
1.  Michael Yankovski	WordStream	5/19/11 	
1.  Augusto Becciu		5/19/11 	
1.  Greg Albrecht		5/19/11 	
1.  Eric James Buth		5/24/11 	
1.  Dan Porter		5/24/11 	
1.  Adrian Silva	Atalanta Systems	5/25/11 	
1.  Spike Morelli	Atalanta Systems	5/25/11 	
1.  Paul Nicholson		5/27/11 	
1.  Mandi Walls		5/27/11 	
1.  Carl Perry	DreamHost	5/29/11 	
1.  Greg Thornton		5/30/11 	
1.  Joseph Heck		6/1/11 	
1.  Charles Ray Johnson, Jr.		6/2/11 	
1.  Joseph Anthony Pasquale Holsten		6/5/11 	
1.  John Donagher		6/6/11 	
1.  David Fuhr	Flagbit 	6/14/11 	
1.  Jörg Weller	Flagbit	6/14/11 	
1.  Marcel Cary		6/15/11 	
1.  Yedidya "Jay" Feldblum	Applications Online	6/17/11 	
1.  Michael Contento		6/20/11 	
1.  Yogesh Pathade		6/22/11 	
1.  Gavin Sandie		6/25/11 	
1.  Bryan Horstmann-Allen		6/28/11 	
1.  Glenn Pratt		7/5/11 	
1.  Andrew Narkewicz	Versapay	7/5/11 	
1.  Zachary Tomas Stevens		7/11/11 	
1.  Richard Gould		7/11/11 	
1.  Philip Cohen		7/15/11 	
1.  Christopher Michael McClimans		7/18/11 	
1.  Jason J.W. Williams		7/19/11 	
1.  Nuo Yan		7/21/11 	
1.  Jaroslaw Śmiejczak		7/25/11 	
1.  Dimitri Aivaliotis	Every Ware	7/25/11 	
1.  Eric Rochester		7/27/11 	
1.  Alex North-Keys	Tippr	7/29/11 	
1.  Adam Knight	Tippr	7/29/11 	
1.  Eugene Wood	Ask.com	8/1/11 	
1.  Aron Bartling	Ask.com	8/1/11 	
1.  Jack Francis	Ask.com	8/1/11 	
1.  Richard Marshall	Ask.com	8/1/11 	
1.  Mikola Kucharski	Ask.com	8/1/11 	
1.  Rory Mitchell	Ask.com	8/3/11 	
1.  Oskar Stolc	Ask.com	8/3/11 	
1.  Jack (John) Roehrig	Ask.com	8/3/11 	
1.  Paul Stahlke	Ask.com	8/3/11 	
1.  Jorge Mazzei	Ask.com	8/3/11 	
1.  Pakojo Samm	Ask.com	8/3/11 	
1.  David Smith	Ask.com	8/3/11 	
1.  Mike Adolphs		8/5/11 	
1.  Ernad Husremović	bring.out doo Sarajevo	8/11/11 	
1.  Jasmin Beganović	bring.out doo Sarajevo	8/11/11 	
1.  Saša Vranić	bring.out doo Sarajevo	8/11/11 	
1.  Šator Emir	bring.out doo Sarajevo	8/11/11 	
1.  Jeremy Bingham	Kos Media	8/15/11 	
1.  Michael Taras	Kos Media	8/15/11 	
1.  Tomoyuki Sakurai	reallyenglish.com	8/15/11 	
1.  Mitsuru Yoshida	reallyenglish.com	8/15/11 	
1.  Avishai Ish-Shalom	Fewbytes	8/18/11 	
1.  Or Cohen	Fewbytes	8/18/11 	
1.  Domenico Delle Side		8/19/11 	
1.  Paul Morton	Business Intelligence Associates	8/19/11 	
1.  Phil Austin	Business Intelligence Associates	8/19/11 	
1.  Andrian Jardan		8/22/11 	
1.  Vladimir Girnet	Tacit Knowledge	8/22/11 	
1.  Scott Askew	Tacit Knowledge	8/22/11 	
1.  Emmett Finneran		8/26/11 	
1.  Arthur Gautier	Zenexity	8/30/11 	
1.  Edward Middleton	ClassDo	8/30/11 	
1.  Michael Pearson		8/31/11 	
1.  Nikolay Sturm		9/1/11 	
1.  Nathan Lloyd Smith		9/1/11 	
1.  Patrick Connolly	Myplanet	9/2/11 	
1.  Yashar Rassoulli	Myplanet	9/2/11 	
1.  James Walker	Myplanet	9/2/11 	
1.  Chris Read		9/6/11 	
1.  Prashant Srivastava		9/7/11 	
1.  Brad Knowles	ihiji	9/16/11 	
1.  Stuart Rench	ihiji	9/16/11 	
1.  Michael Maniscalco	ihiji	9/16/11 	
1.  Brian Cunnie		9/19/11 	
1.  Joseph F. Reynolds		9/20/11 	
1.  Gabriel McArthur		9/21/11 	
1.  David Keith Hudgins		9/21/11 	
1.  Paul MacDougall		9/23/11 	
1.  Bulat Shakirzyanov		9/23/11 	
1.  Jorge Eduardo Espada		9/28/11 	
1.  Eric Dennis		9/28/11 	
1.  Stuart Glenn		9/29/11 	
1.  Bryan Wilson Berry		10/4/11 	
1.  Christopher Sturm		10/5/11 	
1.  John Sumsion		10/12/11 	
1.  Steven Phung		10/13/11 	
1.  Claudio Cesar Sanchez Tejeda		10/14/11 	
1.  Igor Afonov		10/26/11 	
1.  Dan Buettner	Port 80 Production, LLC	10/28/11 	
1.  Robby Grossman		10/31/11 	
1.  Alan Harper		11/1/11 	
1.  Juanje Ojeda		11/1/11 	
1.  Stephane Jourdan	Green Alto	11/2/11 	
1.  Gregory Karekinian	Green Alto	11/2/11 	
1.  Samuel Maftoul	Green Alto	11/2/11 	
1.  Darrin Eden	Heavy Water Software, Inc.	11/4/11 	
1.  Sean Escriva	Heavy Water Software, Inc.	11/4/11 	
1.  Jake Davis	Heavy Water Software, Inc.	11/4/11 	
1.  AJ Christensen	Heavy Water Software, Inc.	11/4/11 	
1.  Michael Weinberg	Heavy Water Software, Inc.	11/4/11 	
1.  Aaron Baer	Heavy Water Software, Inc.	11/4/11 	
1.  Matthew Kanwisher		11/8/11 	
1.  Joshua McKenty		11/9/11 	
1.  Iulian-Corneliu Costan		11/11/11 	
1.  Daniel Oliver		11/14/11 	
1.  Adam Garside		11/15/11 	
1.  Ian Wolfcat Atha	Wealthfront Inc.	11/15/11 	
1.  John Hitchings	Wealthfront Inc.	11/15/11 	
1.  David Fortunato	Wealthfront Inc.	11/15/11 	
1.  Julien Wetterwald	Wealthfront Inc.	11/15/11 	
1.  Kevin Peterson	Wealthfront Inc.	11/15/11 	
1.  Maksim Horbul		11/16/11 	
1.  Roberto Gaiser		11/16/11 	
1.  Robert Di Marco		11/17/11 	
1.  Victor Lowther	Dell	11/17/11 	
1.  Jerry Chen		11/18/11 	
1.  Murali Raju		11/18/11 	
1.  Benjamin Smith		11/18/11 	
1.  Aaron Suggs	Kickstarter, Inc.	11/18/11 	
1.  Lance Ivy	Kickstarter, Inc.	11/18/11 	
1.  Cedric Howe	Kickstarter, Inc.	11/18/11 	
1.  Tieg Zaharia	Kickstarter, Inc.	11/18/11 	
1.  Teemu Matilainen	Reaktor Innovations	11/22/11 	
1.  Dave Solbes	Webtrends Inc	11/22/11 	
1.  Grant Hutchins		11/25/11 	
1.  Eric Saxby	ModCloth	11/27/11 	
1.  Gabriel Evans		11/27/11 	
1.  Tim Smith	Webtrends Inc	11/28/11 	
1.  Nathaniel Eliot	Infochimps, Inc	11/28/11 	
1.  Adam Seever	Infochimps, Inc	11/28/11 	
1.  Travis Dempsey	Infochimps, Inc	11/28/11 	
1.  Dhruv Bansal	Infochimps, Inc	11/28/11 	
1.  Andrew Kaczorek	Cycle Computing, LLC	11/29/11 	
1.  Chris Chalfant	Cycle Computing, LLC	11/29/11 	
1.  Dan Harris	Cycle Computing, LLC	11/29/11 	
1.  Ian Alderman	Cycle Computing, LLC	11/29/11 	
1.  Stephen Balukoff		11/30/11 	
1.  Kendrick Martin	Webtrends Inc	12/1/11 	
1.  Adnan Wahab		12/3/11 	
1.  Alex Howells		12/4/11 	
1.  Cameron Johnston	Needle, Inc.	12/5/11 	
1.  Justin Huff		12/8/11 	
1.  Ian Downes	Ubalo, Inc	12/8/11 	
1.  Erik Hollensbe		12/9/11 	
1.  Karel Minarik		12/11/11 	
1.  Adam Greene	SweetSpot Diabetes Care, Inc.	12/12/11 	
1.  Justin Schumacher	SweetSpot Diabetes Care, Inc.	12/12/11 	
1.  Dan Root	SweetSpot Diabetes Care, Inc.	12/12/11 	
1.  Paul Dowman		12/12/11 	
1.  Andrew Le		12/12/11 	
1.  Paul Welch		12/13/11 	
1.  Harlan Barnes		12/13/11 	
1.  Philip Kates	Rackspace US, Inc	12/13/11 	
1.  Brandon Philips	Rackspace US, Inc	12/13/11 	
1.  Paul Querna	Rackspace US, Inc	12/13/11 	
1.  Arthur Pirogovski		12/13/11 	
1.  John Scott Sanders, Jr	RideCharge, Inc	12/15/11 	
1.  Jamie Winsor	Riot Games	12/15/11 	
1.  Josiah Kiehl	Riot Games	12/15/11 	
1.  Jesse Howarth	Riot Games	12/15/11 	
1.  Michael Matsuuara	Riot Games	12/15/11 	
1.  Cliff Dickerson	Riot Games	12/15/11 	
1.  Philip Gollucci	RideCharge, Inc	12/15/11 	
1.  Radim Marek		12/17/11 	
1.  Hugo Fichter		12/19/11 	
1.  Chris Christensen		12/20/11 	
1.  Chet Luther		12/20/11 	
1.  Mark Luntzel		12/20/11 	
1.  Kevin Karwaski	Fiksu	12/21/11 	
1.  David Calavera		12/22/11 	
1.  Michael Stillwell		12/23/11 	
1.  Aaron Bull Schaefer		12/28/11 	
1.  Max Rabin		1/3/12 	
1.  Michael Bradshaw	WhitePages Inc.	1/3/12 	
1.  Michael Cook	WhitePages Inc.	1/3/12 	
1.  Jack Foy	WhitePages Inc.	1/3/12 	
1.  Devin Ben-Hur	WhitePages Inc.	1/3/12 	
1.  Jeff Bellegarde	WhitePages Inc.	1/3/12 	
1.  John Dyer		1/4/12 	
1.  Sam Marx		1/5/12 	
1.  Praveen Arimbrathodiyil		1/6/12 	
1.  Joshua Buysse		1/6/12 	
1.  Dale Hui		1/6/12 	
1.  Jesse Campbell		1/8/12 	
1.  Roberto Carlos Morano		1/9/12 	
1.  Miah Johnson	Scribd, Inc. 	1/10/12 	
1.  Ian Delahorne		1/12/12 	
1.  Mike Javorski	Spoke Software	1/15/12 	
1.  Michael A. Fiedler		1/16/12 	
1.  Luis Bosque		1/16/12 	
1.  Qiming He		1/18/12 	
1.  Hector Castro		1/19/12 	
1.  Wade Warren	Wikia	1/23/12 	
1.  Geoff Papilion	Wikia	1/23/12 	
1.  Justin Ryan	Wikia	1/23/12 	
1.  David King	Xforty Technologies	1/25/12 	
1.  Christian Pearce	Xforty Technologies	1/25/12 	
1.  Andrew Libby	Xforty Technologies	1/25/12 	
1.  Joshua Hou		1/27/12 	
1.  Alice Kaerast		1/28/12 	
1.  Brett Hoerner		1/28/12 	
1.  Jon-Erik Schneiderhan		1/30/12 	
1.  Wes Morgan	Democracy Works, Inc	1/30/12 	
1.  Ernie Brodeur		1/31/12 	
1.  Stephen Figgins		1/31/12 	
1.  Tal Rotbart		2/1/12 	
1.  Benjamin Lindsey		2/1/12 	
1.  Markus Schirp		2/1/12 	
1.  Tryn Mirell		2/2/12 	
1.  Hari Krishna Dara		2/7/12 	
1.  Andrew Grangaard		2/8/12 	
1.  Adam Mielke		2/8/12 	
1.  Andrew Allan		2/9/12 	
1.  Antonio Soares de Azevedo Terceiro		2/9/12 	
1.  Istvan Szukacs		2/9/12 	
1.  Brian Parker	Pure Lake Software, Inc.	2/10/12 	
1.  Sean Porter		2/10/12 	
1.  William Carroll		2/12/12 	
1.  Paul Diaconescu	Sveriges Television AB	2/14/12 	
1.  Jonas Eklof	Sveriges Television AB	2/14/12 	
1.  Per Bjorn	Sveriges Television AB	2/14/12 	
1.  Frank Hoffsumer	Sveriges Television AB	2/14/12 	
1.  Samppa Kytomaki	Reaktor Innovations	2/14/12 	
1.  Zuhaib Siddique	Atlassian	2/14/12 	
1.  Andrew Robson	Oxygen Cloud, Inc.	2/14/12 	
1.  Aaron Follette	Oxygen Cloud, Inc.	2/14/12 	
1.  Erik Bakker		2/16/12 	
1.  David Golden		2/16/12 	
1.  Jacques Chester	Robojar Pty Ltd	2/17/12 	
1.  Nicholas VINOT		2/18/12 	
1.  Matthew MacDonald-Wallace		2/19/12 	
1.  Andrew Gross		2/20/12 	
1.  Andrew Fecheyr Lippins		2/21/12 	
1.  Shoaib Kamil		2/21/12 	
1.  Martin Vidner		2/23/12 	
1.  Jake Ritorto	ModCloth	2/23/12 	
1.  Seth Kingry	ModCloth	2/23/12 	
1.  Manuel Gutierrez	ModCloth	2/23/12 	
1.  Graham McMillan	World Wide Web Hosting, LLC	2/24/12 	
1.  Nicholas Stielau		2/24/12 	
1.  McClain Looney		2/24/12 	
1.  Jim Meyer		2/29/12 	
1.  Trevor Orsztynowicz	Joyent	2/29/12 	
1.  Kevin Chang	Joyent	2/29/12 	
1.  Geoffery Nix	ModCloth	3/1/12 	
1.  Roberto Sanchez	ModCloth	3/1/12 	
1.  Dan Buch	ModCloth	3/1/12 	
1.  Ziad Sawalha	Rackspace	3/2/12 	
1.  Benedikt Böhm		3/4/12 	
1.  Steven Ivy	Wallrazer, Inc.	3/4/12 	
1.  Krzysztof Wilczynski		3/5/12 	
1.  Elson Orlando Rodriguez		3/5/12 	
1.  Michael Schubert		3/5/12 	
1.  Douglas Thrift	Rightscale	3/5/12 	
1.  Andrew Benz		3/6/12 	
1.  Yann Robin	Youscribe	3/6/12 	
1.  Javier Frias		3/6/12 	
1.  Josh Miller	Edmunds.com	3/6/12 	
1.  Moritz Winter		3/6/12 	
1.  Aaron Blythe	Cerner Innovation, Inc.	3/8/12 	
1.  Kevin Shekleton	Cerner Innovation, Inc.	3/8/12 	
1.  Josh Murphy	Cerner Innovation, Inc.	3/8/12 	
1.  Bryan Baugher	Cerner Innovation, Inc.	3/8/12 	
1.  Sachin Sagar Ra		3/8/12 	
1.  Tarik Jabri		3/8/12 	
1.  Michael W. Myers		3/10/12 	
1.  Marcus Cobden		3/11/12 	
1.  Coimbatore Sankarraman Shyam Sundar		3/12/13 	
1.  Chris Roberts	Heavy Water Software, Inc.	3/13/12 	
1.  Justin Mazzi	World Wide Web Hosting, LLC	3/13/12 	
1.  Joshua Priddle	World Wide Web Hosting, LLC	3/13/12 	
1.  Paul Stengel	World Wide Web Hosting, LLC	3/13/12 	
1.  Vince Stratful	World Wide Web Hosting, LLC	3/13/12 	
1.  Artem Veremey		3/13/12 	
1.  Jon Cowie		3/15/12 	
1.  Philip Kromer	Infochimps, Inc	3/17/12 	
1.  Ben Dean		3/18/12 	
1.  Zachary Cook		3/19/12 	
1.  Welby McRoberts		3/20/12 	
1.  Ian Coffey	Voxel Dot Net, Inc	3/20/12 	
1.  David Amian Valle		3/21/12 	
1.  Lewis J. Goettner, III		3/21/12 	
1.  Bernardo Gomez Palacio 		3/23/12 	
1.  Chris Gaffney 		3/23/12 	
1.  Igor Kurochkin		3/24/12 	
1.  Oleksiy Kovyrin 		3/24/12 	
1.  Jordan Dea-Mattson	Numenta, Inc.	3/26/12 	
1.  Cody Ebberson	Numenta, Inc.	3/27/12 	
1.  Martin Hasan Bramwell		3/28/12 	
1.  Mohammed Siddick		3/28/12 	
1.  Ira Abramaov	Fewbytes	3/29/12 	
1.  Paul McCallick		3/29/12 	
1.  Jon-Paul Sullivan	Hewlett-Packard	3/30/12 	
1.  Sascha Bates		3/30/12 	
1.  Julian Cardona	Edmunds.com	4/2/12 	
1.  David Hudson	Edmunds.com	4/2/12 	
1.  Andrew Crump	Kotiri Software Ltd.	4/3/12 	
1.  Zach Dunn		4/5/12 	
1.  Logan Lowell	The Frontside Software, Inc.	4/5/12 	
1.  Charles Lowell	The Frontside Software, Inc.	4/5/12 	
1.  Chris Buben		4/5/12 	
1.  Joseph Brian Passavanti		4/5/12 	
1.  Denis Barishev		4/6/12 	
1.  Jonas Courteau		4/6/12 	
1.  Eric Hankins		4/10/12 	
1.  Chris Buben	Gap, Inc.	4/10/12 	
1.  Oliver Fross	Gap, Inc.	4/10/12 	
1.  Jeffery Padgett	Gap, Inc.	4/10/12 	
1.  Philip Vieira		4/10/12 	
1.  Guilhem Lettron	Youscribe	4/11/12 	
1.  Sebastien Balant	Youscribe	4/11/12 	
1.  Robert E. Lewis		4/13/12 	
1.  David Joos		4/16/12 	
1.  Umang Chouhan		4/16/12 	
1.  Sören Blom	Deutsche Telekom Laboratories	4/17/12 	
1.  Alex Redington	Relevance, Inc.	4/20/12 	
1.  Gabriel Horner	Relevance, Inc.	4/20/12 	
1.  Lake Denman	Relevance, Inc.	4/20/12 	
1.  Larry Karnowski	Relevance, Inc./Truer Sound LLC	4/20/12 	
1.  Sam Umbach	Relevance, Inc./Truer Sound LLC	4/20/12 	
1.  Jeremiah Snapp	Asbury Theological Seminary	4/20/12 	
1.  Brian Bianco		4/20/12 	
1.  Brandon Martin		4/21/12 	
1.  Alexander Gordeev		4/24/12 	
1.  Joe Miller		4/25/12 	
1.  Nick Peirson		4/27/12 	
1.  Marc Morata Fite		4/27/12 	
1.  Seth Thomas		4/27/12 	
1.  Chris Griego		4/28/12 	
1.  Dmytro Ilchenko		4/30/12 	
1.  Morgan Nelson		4/30/12 	
1.  Chirag Jog	Websym Technologies Private Ltd.	4/30/12 	
1.  Kalpak Shah	Websym Technologies Private Ltd.	4/30/12 	
1.  Mohit Sethi	Websym Technologies Private Ltd.	4/30/12 	
1.  Kyle VanderBeek		5/2/12 	
1.  TANABE Ken-ichi		5/2/12 	
1.  Brandon Adams	DreamBox Learning, Inc.	5/3/12 	
1.  Hui Hu		5/5/12 	
1.  Will Maier	Simple	5/7/12 	
1.  Chris Brentano	Simple	5/7/12 	
1.  Cosmin Stejerean	Simple	5/7/12 	
1.  Brian Merritt	Simple	5/7/12 	
1.  Pascal Deschenes		5/8/12 	
1.  Michael Glenn		5/8/12 	
1.  Dan Crosta		5/9/12 	
1.  Daniel Condomitti		5/9/12 	
1.  Matthew Butcher		5/10/12 	
1.  Ben Poweski	Consumer Club, Inc.	5/10/12 	
1.  Chris Griego	Consumer Club, Inc.	5/10/12 	
1.  Jim Hughes	Consumer Club, Inc.	5/10/12 	
1.  Morgan Nelson	Consumer Club, Inc.	5/10/12 	
1.  Kristina Rodgers	Consumer Club, Inc.	5/10/12 	
1.  Derek Schultz		5/11/12 	
1.  Anay Nayak		5/15/12 	
1.  Patrick Ting		5/17/12 	
1.  Xabier de Zuazo Oteiza	Onddo Labs	5/18/12 	
1.  Raul Rodriguez Munoz	Onddo Labs	5/18/12 	
1.  Ramez Mourad		5/21/12 	
1.  Jonathan Manton		5/22/12 	
1.  Philipp Wollermann	CyberAgent Corp.	5/22/12 	
1.  Koji Hasebe	CyberAgent Corp.	5/22/12 	
1.  Jean-Daniel Bussy	CyberAgent Corp.	5/22/12 	
1.  Yoshihisa Sakamoto	CyberAgent Corp.	5/22/12 	
1.  Kohei Maeda	CyberAgent Corp.	5/22/12 	
1.  Eric Edgar		5/23/12 	
1.  Rodolphe Blancho		5/23/12 	
1.  Kevin Nuckolls		5/24/12 	
1.  Michael Nygard	Relevance, Inc.	5/29/12 	
1.  Martin Fenner		5/30/12 	
1.  Lukasz Kaniowski		5/31/12 	
1.  Brian Flad		5/31/12 	
1.  Justin Witrick	Rackspace	6/1/12 	
1.  Nickalaus Willever		6/1/12 	
1.  Harold "Waldo" Grunenwald III		6/4/12 	
1.  Bjorn Albers		6/4/12 	
1.  Timothy Martin Potter		6/5/12 	
1.  Greg Fitzgerald		6/6/12 	
1.  Sebastian Wendel	SourceIndex IT-Services	6/7/12 	
1.  Leif Madsen		6/7/12 	
1.  Jonathan del Strother		6/7/12 	
1.  Bernd Roth		6/8/12 	
1.  Madhurranjan Mohaan		6/11/12 	
1.  Seth Vargo		6/11/12 	
1.  Gregory Jones		6/12/12 	
1.  Joshua Brand		6/15/12 	
1.  David Stainton	Scribd, Inc.	6/15/12 	
1.  Sriram Devadas		6/17/12 	
1.  Christopher Webber		6/17/12 	
1.  Raf Geens	Civolution BV	6/18/12 	
1.  Greg Symons	Drillinginfo	6/18/12 	
1.  Clark Archer	Drillinginfo	6/18/12 	
1.  David Eddy		6/18/12 	
1.  Jonathan Hartman	Rackspace	6/21/12 	
1.  Boyd Edward Hemphill		6/21/12 	
1.  Martha Greenberg		6/24/12 	
1.  Paul Meserve		6/25/12 	
1.  Michael H. Oshita		6/25/12 	
1.  James W. Brinkerhoff	Voxel Dot Net, Inc	6/26/12 	
1.  Evan Vetere	Voxel Dot Net, Inc	6/26/12 	
1.  Kris Beevers	Voxel Dot Net, Inc	6/26/12 	
1.  Patrick Dowell	Voxel Dot Net, Inc	6/26/12 	
1.  Zachary Voase		6/26/12 	
1.  Paul Guth	The Cloudscaling Group, Inc.	6/27/12 	
1.  Rodolphe Pineau	The Cloudscaling Group, Inc.	6/27/12 	
1.  Jeremy Deininger	The Cloudscaling Group, Inc.	6/27/12 	
1.  Blake Barnett	The Cloudscaling Group, Inc.	6/27/12 	
1.  HIGUCHI Daisuke	Creationline, Inc.	6/27/12 	
1.  Jey Hotta	Creationline, Inc.	6/27/12 	
1.  Kent R. Spillner		7/6/12 	
1.  Brian Dols		7/6/12 	
1.  Frank Rosquin		7/10/12 	
1.  Bill Moritz		7/10/12 	
1.  Alfred Rossi	Action Verb, LLC	7/10/12 	
1.  Patrick Ribeiro Negri	lugu Seervicos na Internet LTDA	7/11/12 	
1.  Marcelo Paez	lugu Seervicos na Internet LTDA	7/11/12 	
1.  Alexandre Paez	lugu Seervicos na Internet LTDA	7/11/12 	
1.  Wong Liang Zan		7/11/12 	
1.  Matthew Andersen		7/12/12 	
1.  Jacob Atzen		7/13/12 	
1.  Chris Parsons		7/13/12 	
1.  Timothy Jones		7/14/12 	
1.  Ameya Prakash Gangamwar		7/15/12 	
1.  Adrien Brault		7/16/12 	
1.  Michael T. Halligan		7/17/12 	
1.  Andreas Boehrnsen	OpeniT	7/18/12 	
1.  Jay Levitt		7/20/12 	
1.  Jose Luis Fernandez Perez		7/21/12 	
1.  Aaron J. Peterson		7/22/12 	
1.  Jim Croft	Cloudreach Limited	7/24/12 	
1.  Richard Bowden	Cloudreach Limited	7/24/12 	
1.  Joe Geldart	Cloudreach Limited	7/24/12 	
1.  Bryce Lynn	Tacit Knowledge	7/24/12 	
1.  Brian Smith	Bonnier Corporation	7/25/12 	
1.  Michael Linde	Bonnier Corporation	7/25/12 	
1.  Peter Lauda	Bonnier Corporation	7/25/12 	
1.  Rakesh Patel	OneHealth Solutions, Inc.	7/25/12 	
1.  Jay Perry		7/26/12 	
1.  Mark Roddy		7/26/12 	
1.  Andrew Regan		7/26/12 	
1.  Takeshi Kondo		7/26/12 	
1.  Paul Rossman		7/26/12 	
1.  Bryan Stearns	Paydici Corp.	7/26/12 	
1.  Jim Harvey	Paydici Corp.	7/26/12 	
1.  Bill Burcham	Paydici Corp.	7/26/12 	
1.  Steve Rude		7/26/12 	
1.  Richard Clamp		7/29/12 	
1.  Christopher Kelly		7/30/12 	
1.  Deepak Kannan		7/30/12 	
1.  Roy Liu		7/31/12 	
1.  Artiom Lunev		7/31/12 	
1.  Anna Marseille D. Gabutero		7/31/12 	
1.  Lucas Jandrew	Riot Games	8/1/12 	
1.  Dafydd Crosby		8/1/12 	
1.  Christoph Thiel	Novell, Inc.	8/1/12 	
1.  Ralf Haferkamp	Novell, Inc.	8/1/12 	
1.  Adam Spiers	Novell, Inc.	8/1/12 	
1.  Tim Serong	Novell, Inc.	8/1/12 	
1.  Sascha Peilicke	Novell, Inc.	8/1/12 	
1.  Bernhard Wiedemann	Novell, Inc.	8/1/12 	
1.  Ionuts Artarisi	Novell, Inc.	8/1/12 	
1.  Vincent Untz	Novell, Inc.	8/1/12 	
1.  Martin Vidner	Novell, Inc.	8/1/12 	
1.  J. Daniel Schmidt	Novell, Inc.	8/1/12 	
1.  Stefan Fent	Novell, Inc.	8/1/12 	
1.  Danny Kukawka	Novell, Inc.	8/1/12 	
1.  Michal Vyskocil	Novell, Inc.	8/1/12 	
1.  Kristian Vlaardingerbroek	Schuberg Philis B.V.	8/3/12 	
1.  Jon Gretarsson	RelatelIQ Inc.	8/3/12 	
1.  Danial Pearce		8/5/12 	
1.  Stathis Touloumis		8/5/12 	
1.  Matthew Scott Moyer		8/7/12 	
1.  Benedict Steele		8/7/12 	
1.  James Tan	Novell, Inc.	8/7/12 	
1.  John Kip Larsen		8/8/12 	
1.  Chris Buryta		8/9/12 	
1.  Sahil Muthoo		8/10/12 	
1.  Kyle Goodwin	PrimeRevenue, Inc	8/10/12 	
1.  Ben Rosenblum	PrimeRevenue, Inc	8/10/12 	
1.  Aaron Kalin		8/10/12 	
1.  John Dewey		8/11/12 	
1.  Abel Lopez		8/13/12 	
1.  Lyndon Washington		8/14/12 	
1.  Ripal Nathuji	Calxeda	8/14/12 	
1.  Gardner Bickford		8/15/12 	
1.  Nick Heppner		8/16/12 	
1.  Jeffrey Dutton		8/16/12 	
1.  Taklon Wu		8/17/12 	
1.  Craig Tracey		8/17/12 	
1.  Lee Jensen	Big Cartel LLC	8/17/12 	
1.  Chris Cameron	Big Cartel LLC	8/17/12 	
1.  Kelley Reynolds	Big Cartel LLC	8/17/12 	
1.  Michael Wallman		8/17/12 	
1.  Edward Sargisson		8/19/12 	
1.  Winfield Peterson		8/20/12 	
1.  Mathew Davies		8/21/12 	
1.  Justin Shepherd	Rackspace	8/21/12 	
1.  Jason Cannavale	Rackspace	8/21/12 	
1.  Ron Pedde	Rackspace	8/21/12 	
1.  Joseph Breu	Rackspace	8/21/12 	
1.  William Kelly	Rackspace	8/21/12 	
1.  Darren Birkett	Rackspace	8/21/12 	
1.  Evan Callicoat	Rackspace	8/21/12 	
1.  Andrew Ferk		8/23/12 	
1.  Shaun Hope		8/23/12 	
1.  Matt Kynaston		8/24/12 	
1.  Ben Marini		8/25/12 	
1.  Garret Heaton	Atlassian	8/27/12 	
1.  Julian Dunn		8/27/12 	
1.  Jordan Evans		8/28/12 	
1.  Andrew Laski		8/31/12 	
1.  Mat Schaffer		8/31/12 	
1.  Elliot Pahl		9/3/12 	
1.  Richard Shade	Rightscale	9/5/12 	
1.  Dmytro Kovalov		9/5/12 	
1.  Shishir Das		9/6/12 	
1.  Kimball Johnson	One Connect Limited	9/7/12 	
1.  Roy Crombleholme	One Connect Limited	9/7/12 	
1.  Martin Foster	One Connect Limited	9/7/12 	
1.  Alex Klepa		9/7/12 	
1.  Brendan Hay		9/7/12 	
1.  Paul Graydon		9/7/12 	
1.  Steve Layland		9/7/12 	
1.  Thomas Dudziak		9/7/12 	
1.  Felix Sheng		9/8/12 	
1.  Sean Porter	Sonian Inc	9/8/12 	
1.  Josh Pasqualetto	Sonian Inc	9/8/12 	
1.  TJ Vanderpoel	Sonian Inc	9/8/12 	
1.  Justin Kolberg	Sonian Inc	9/8/12 	
1.  Decklin Foster	Sonian Inc	9/8/12 	
1.  Randall Morse		9/10/12 	
1.  Pete Cheslock	Dyn	9/10/12 	
1.  Max Stepanov		9/11/12 	
1.  Sean Gallagher		9/11/12 	
1.  Autif Khan		9/11/12 	
1.  Jacques Marneweck		9/12/12 	
1.  William Herry		9/16/12 	
1.  Pawel Kozlowski		9/16/12 	
1.  Lawrence Gilbert		9/18/12 	
1.  Bob Walker		9/18/12 	
1.  Nathan Schimke		9/18/12 	
1.  Graham Christensen		9/19/12 	
1.  Alessandro Dal Grande	The App Business	9/19/12 	
1.  Saager Suhas Mhatre		9/23/12 	
1.  Charles J Blaine		9/23/12 	
1.  Andres de Barbara		9/23/12 	
1.  Adam Vinsh		9/25/12 	
1.  Elliot Murphy	Pat Deegan, PhD & Associates, LLC	9/26/12 	
1.  John Nishinaga	Pat Deegan, PhD & Associates, LLC	9/26/12 	
1.  Farley Knight	Pat Deegan, PhD & Associates, LLC	9/26/12 	
1.  Jon Sime	OmniTI	9/26/12 	
1.  Clinton Wolfe	OmniTI	9/26/12 	
1.  Theo Schlossnagle	OmniTI	9/26/12 	
1.  Robert Treat	OmniTI	9/26/12 	
1.  Adam DePue		9/26/12 	
1.  Martin Contento		9/27/12 	
1.  Milos Gajdos		9/27/12 	
1.  Brad Gignac	Rackspace	9/28/12 	
1.  Robert Allen		9/30/12 	
1.  Chia-liang Kao		10/1/12 	
1.  Ketan Padegaonkar		10/2/12 	
1.  Antti Puranen	Reaktor Innovations	10/5/12 	
1.  Stephen Crawley		10/7/12 	
1.  Brad Bennet	ZestFinance	10/8/12 	
1.  Alexander Tamoykin	ZestFinance	10/8/12 	
1.  Lloyd Philbrook	Firebelly Design	10/8/12 	
1.  Nate Beaty	Firebelly Design	10/8/12 	
1.  John Skopis		10/8/12 	
1.  Susan Potter		10/8/12 	
1.  Jatinder Giri		10/10/12 	
1.  Joan Touzet	Cloudant, Inc.	10/11/12 	
1.  Kyle Allan	Riot Games	10/11/12 	
1.  Jay Pipes		10/12/12 	
1.  John Austin Page		10/15/12 	
1.  Chuck Ha		10/15/12 	
1.  David Dvorak	Webtrends	10/15/12 	
1.  Dipen Lad		10/15/12 	
1.  Pascal Deschenes	Nu Echo	10/16/12 	
1.  Matthieu Vachon	Nu Echo	10/16/12 	
1.  Raymond Menard	Nu Echo	10/16/12 	
1.  Jean-Francois Alix	Nu Echo	10/16/12 	
1.  Mariano Cortesi		10/16/12 	
1.  Alexander Phan		10/16/12 	
1.  Jeff Siegel		10/16/12 	
1.  William Milton		10/17/12 	
1.  Mark Pimentel		10/18/12 	
1.  Mike Gifford	OpenConcept	10/18/12 	
1.  Mike Mallett	OpenConcept	10/18/12 	
1.  Brian Loomis		10/20/12 	
1.  Michael Saffitz	Apptentive	10/20/12 	
1.  Andrew Wooster	Apptentive	10/20/12 	
1.  Sky Kelsey	Apptentive	10/20/12 	
1.  Benjamin Michael Atkin	Document Swarm, LLC	10/20/12 	
1.  Andreas Gerauer		10/22/12 	
1.  Steven Deaton		10/22/12 	
1.  Cassiano Bertol Leal		10/23/12 	
1.  Matt Towers		10/23/12 	
1.  Mark Ayers		10/23/12 	
1.  Anthony Leto		10/23/12 	
1.  Marc Soda		10/24/12 	
1.  Jerome D Harrington, II		10/24/12 	
1.  Russell Stewart Egan		10/24/12 	
1.  Paul Thomas		10/24/12 	
1.  Chris Lundquist		10/24/12 	
1.  Anton Orel		10/25/12 	
1.  Marius Sturm		10/25/12 	
1.  Dimitri David Boelaert-Roche		10/25/12 	
1.  Matthew Serafin Horan		10/25/12 	
1.  Vojtech Hyza		10/25/12 	
1.  Steve Houser		10/26/12 	
1.  Dmitry Zamaruev		10/29/12 	
1.  James Hu		10/29/12 	
1.  Laust Rud Jacobsen		10/29/12 	
1.  Zo Obradovic		10/29/12 	
1.  Dale Kiefling		10/29/12 	
1.  Todd Fleisher		10/29/12 	
1.  Karl Freeman		10/30/12 	
1.  Johannes Becker		10/30/12 	
1.  Fred Sadaghiani	Sift Science, Inc.	10/31/12 	
1.  Jeff Thompson		10/31/12 	
1.  Stanislav Bogatyrev		10/31/12 	
1.  Jonathan Peck	FluxSauce	11/1/12 	
1.  Jeffrey Borg		11/1/12 	
1.  Guido Serra	Rocket Internet GmbH	11/2/12 	
1.  Sebastian Grewe		11/3/12 	
1.  Chaoran Xie		11/3/12 	
1.  Julien Duponchelle		11/4/12 	
1.  Trae Robrock		11/5/12 	
1.  Nikita Borzykh		11/6/12 	
1.  Ilya Sher		11/6/12 	
1.  Michael Fischer		11/6/12 	
1.  Nathan Baxter		11/6/12 	
1.  Simon Belluzzo		11/6/12 	
1.  Ben Hartshorne		11/9/12 	
1.  Matt Whiteley	Engine Yard	11/9/12 	
1.  Raul Naveiras		11/13/12 	
1.  Eugene Wood		11/13/12 	
1.  Javier Perez-Griffo	Tapp	11/13/12 	
1.  Dang Nguyen		11/13/12 	
1.  Pablo Banos	Tapp	11/13/12 	
1.  Christian Hofer	Tapp	11/13/12 	
1.  Matthew Rogers		11/13/12 	
1.  Stephen Lauck		11/13/12 	
1.  Mark Van de Vyver	Taqtiqa LLC	11/14/12 	
1.  Thomas Carroll		11/14/12 	
1.  Jon DeCamp	Nordstrom, Inc	11/15/12 	
1.  Doug Ireton	Nordstrom, Inc	11/15/12 	
1.  Kevin Moser	Nordstrom, Inc	11/15/12 	
1.  Justin Schumacher	Nordstrom, Inc	11/15/12 	
1.  Rob Cummings	Nordstrom, Inc	11/15/12 	
1.  Brandon Burton		11/20/12 	
1.  Christopher Ferry		11/20/12 	
1.  Michael Hood		11/22/12 	
1.  Gavin Montague		11/23/12 	
1.  Michal Lomnicki		11/24/12 	
1.  Doc Walker		11/24/12 	
1.  Nicolas Szalay		11/26/12 	
1.  Terry Carr		11/26/12 	
1.  Michael Myers	Daptiv Solutions LLC	11/26/12 	
1.  Shawn Neal	Daptiv Solutions LLC	11/26/12 	
1.  Chris Bobo	Daptiv Solutions LLC	11/26/12 	
1.  Ian Gantt	Daptiv Solutions LLC	11/26/12 	
1.  Alan Gray	Daptiv Solutions LLC	11/26/12 	
1.  Kishore Kumar S		11/26/12 	
1.  Vincent Leraitre		11/27/12 	
1.  Samuel Gerstein		11/27/12 	
1.  John T Skarbek		11/27/12 	
1.  Paul A Jungwirth		11/28/12 	
1.  Thomas Hodder	Lime Pepper Ltd	11/28/12 	
1.  Warren Vosper	Straydog Software, Inc.	11/29/12 	
1.  Joshua Reedy		11/30/12 	
1.  Mehmet Ali Akmanalp		11/30/12 	
1.  Panagiotis Papadomitsos		11/30/12 	
1.  Allan Espinosa		11/30/12 	
1.  Brian Pitts		12/1/12 	
1.  Elliot Kendall		12/3/12 	
1.  Nathan Mische		12/3/12 	
1.  Matthew Turney		12/3/12 	
1.  Jay Flowers		12/4/12 	
1.  Loic Antoine-Gombeaud		12/5/12 	
1.  Joe Rodriguez		12/5/12 	
1.  Kyle Scarmardo	Fidelity Technology Group, LLC	12/6/12 	
1.  Jon Lenzer	Fidelity Technology Group, LLC	12/6/12 	
1.  Chaoran Xie	Fidelity Technology Group, LLC	12/6/12 	
1.  Shalon Wood	Fidelity Technology Group, LLC	12/6/12 	
1.  David Crane		12/6/12 	
1.  Takumi IINO		12/9/12 	
1.  Tolleiv Nietsch		12/9/12 	
1.  Benoit Caron		12/9/12 	
1.  Mathieu Martin		12/10/12 	
1.  Yung Giang		12/11/12 	
1.  Fabian Ruff		12/11/12 	
1.  Takeshi KOMIYA		12/11/12 	
1.  Rafael Fonseca		12/12/12 	
1.  Justin Campbell		12/12/12 	
1.  Andrey Subbota		12/13/12 	
1.  Jacob Ritorto		12/13/12 	
1.  Pierre Ozoux		12/14/12 	
1.  Shoaib Mushtaq		12/16/12 	
1.  Arnold Krille	bcs kommunikationslosungen	12/17/12 	
1.  Rainer Dietz	bcs kommunikationslosungen	12/17/12 	
1.  Paul Diaconescu		12/17/12 	
1.  Jake Davis	Simple	12/17/12 	
1.  Mike Ehlert	Simple	12/17/12 	
1.  Kevin Bringard		12/19/12 	
1.  David Whittington		12/20/12 	
1.  Raphael Valyi		12/20/12 	
1.  Michael Klapper		12/23/12 	
1.  Eli Klein		12/24/12 	
1.  Andrew Lawrence Burns		12/26/12 	
1.  Kevin Keane	North County Tech Center, LLC	12/26/12 	
1.  David Petzel		12/28/12 	
1.  Thomas Robison		12/28/12 	
1.  Keenan Brock		12/28/12 	
1.  Stefan Borsje		12/29/12 	
1.  Jon Galentine		12/29/12 	
1.  Kiesia Croucher		12/31/12 	
1.  Deeba Siddiqi		1/2/13 	
1.  Steven De Coeyer		1/2/13 	
1.  Yoni Yalovitsky	Fewbytes	1/2/13 	
1.  Alex Kiernan		1/3/13 	
1.  Gilles Cornu		1/4/13 	
1.  Gavin Mogan		1/4/13 	
1.  Steven Lehrburger		1/4/13 	
1.  Jordi Llonch		1/6/13 	
1.  Nicolas Rycar		1/7/13 	
1.  Andrew McCloud		1/7/13 	
1.  Gregoire Seux	Criteo	1/8/13 	
1.  Brian Scott	Emergent One	1/9/13 	
1.  Mike Taczak	Emergent One	1/9/13 	
1.  Javier Segura Martinez		1/9/13 	
1.  Warren Bain	Ninefold Pty Limited	1/9/13 	
1.  Shaun Domingo	Ninefold Pty Limited	1/9/13 	
1.  Toby Hede	Ninefold Pty Limited	1/9/13 	
1.  Paul Handly	DecisionDesk	1/13/13 	
1.  Eric Neuman	DecisionDesk	1/13/13 	
1.  Will Olbrys	DecisionDesk	1/13/13 	
1.  Thomas Bouve		1/14/13 	
1.  Kevin Reedy	Belly Inc	1/15/13 	
1.  Craig Ulliott	Belly Inc	1/15/13 	
1.  Jay OConnor	Belly Inc	1/15/13 	
1.  Courtenay Gasking		1/16/13 	
1.  James Dabbs		1/16/13 	
1.  Jerry Cattell		1/16/13 	
1.  Jon Webb		1/17/13 	
1.  Hendrik Volkmer	cloudbau Gmbh	1/18/13 	
1.  Thomas Kadauke	cloudbau Gmbh	1/18/13 	
1.  Martin Bosner	cloudbau Gmbh	1/18/13 	
1.  Christopher Laco		1/18/13 	
1.  Haggai Philip Zagury		1/19/13 	
1.  Eric Sigler		1/20/13 	
1.  Yves Vogl		1/21/13 	
1.  Yukihiko Sawanobori	HiganWorks LLC	1/21/13 	
1.  Seth Larson		1/21/13 	
1.  Ben Langeld		1/21/13 	
1.  Dan Midwood		1/22/13 	
1.  Peter Pouliot		1/22/13 	
1.  Alexander Bondarev		1/23/13 	
1.  Ben Dean	Ontario Systems	1/23/13 	
1.  Keith Shook	Ontario Systems	1/23/13 	
1.  Lucas Heinlen	Ontario Systems	1/23/13 	
1.  Kyle Michel	Ontario Systems	1/23/13 	
1.  Brice Oliver	Ontario Systems	1/23/13 	
1.  David Rogers	Lytro, Inc.	1/23/13 	
1.  Alvin Lai	Lytro, Inc.	1/23/13 	
1.  Anuj Biyani	Lytro, Inc.	1/23/13 	
1.  Tiffany Russo	Lytro, Inc.	1/23/13 	
1.  Craig Brunner	Lytro, Inc.	1/23/13 	
1.  Mugur Marculescu	Lytro, Inc.	1/23/13 	
1.  Tom Hanley	Lytro, Inc.	1/23/13 	
1.  Thomas Massmann		1/25/13 	
1.  Ankit Shah		1/25/13 	
1.  Josh Mahowald		1/25/13 	
1.  Christopher Bandy		1/25/13 	
1.  Mal Graty		1/27/13 	
1.  Vaidas Jablonskis		1/27/13 	
1.  Simon McCartney		1/28/13 	
1.  Jake Davis		1/29/13 	
1.  Sean Kilgore		1/29/13 	
1.  Scott Lampert		1/29/13 	
1.  Michael Frick		1/29/13 	
1.  Kevin Duane		1/30/13 	
1.  Ryan Geyer		1/30/13 	
1.  George Hafiz		1/30/13 	
1.  Eric Pardee	Atlas Digital, LLC	1/30/13 	
1.  Jaroslaw Zmudzinski	Grupa Allegro Sp. z o.o.	1/31/13 	
1.  Alexey Polovinkin		2/1/13 	
1.  Malte Swart		2/2/13 	
1.  Jon Burgess		2/3/13 	
1.  Daniel Hahn		2/4/13 	
1.  Maxime Brugidou	Criteo	2/4/13 	
1.  Gareth David Rushgrove		2/4/13 	
1.  Michael Conigliaro		2/4/13 	
1.  James Kessler		2/4/13 	
1.  Lukasz Jagiello		2/4/13 	
1.  Mischa Taylor		2/4/13 	
1.  Mervyn Hammer	Workday Inc.	2/5/13 	
1.  David Radcliffe		2/5/13 	
1.  Alexander Titov		2/5/13 	
1.  Buntaro OKADA		2/5/13 	
1.  Alexey Kalinin		2/5/13 	
1.  Adam Cownoble		2/6/13 	
1.  Josh Behrends	Webtrends	2/6/13 	
1.  Mark Shlimovich		2/6/13 	
1.  Jahn Bertsch		2/7/13 	
1.  Sergio Rodriguez		2/7/13 	
1.  Timur Batyrshin		2/8/13 	
1.  Samuel Cooper		2/8/13 	
1.  Ignacy Kasperowicz		2/8/13 	
1.  Ranjib Dey		2/8/13 	
1.  Kirill Kouznetsov		2/8/13 	
1.  Jordan Hagan		2/8/13 	
1.  Alexander Coles		2/9/13 	
1.  Michael Grosser		2/10/13 	
1.  Michael Goetz		2/11/13 	
1.  Patrick Humpal		2/11/13 	
1.  Nate Smith		2/13/13 	
1.  Martin Eigenbrodt		2/13/13 	
1.  Russell Cloran		2/13/13 	
1.  John Gabriel McArthur		2/13/13 	
1.  Jessica Bourne		2/13/13 	
1.  Darren Haken		2/14/13 	
1.  Rick Polk		2/14/13 	
1.  Eric Berg		2/14/13 	
1.  Andrew Williams	Intoximeters	2/15/13 	
1.  Matthew Follett	Intoximeters	2/15/13 	
1.  Brendan O'Donnell		2/16/13 	
1.  Igor Serebryany	Airbnb	2/17/13 	
1.  Lukas Reinfurt		2/17/13 	
1.  Adam Gross		2/17/13 	
1.  Giorgio Valoti		2/19/13 	
1.  Nathan Beyer	Cerner Corporation	2/19/13 	
1.  Patrik Stenmark	Valtech AB	2/20/13 	
1.  Evgeny Zislis		2/20/13 	
1.  Luyi Wang		2/20/13 	
1.  Jason Schadel	AWeber Communications	2/20/13 	
1.  David Kinzer		2/22/13 	
1.  Achim Rosenhagen		2/23/13 	
1.  Doug Cole		2/23/13 	
1.  Matthew Wright		2/25/13 	
1.  Jasper Lievisse Adriaanse		2/25/13 	
1.  Julien Vehent	AWeber Communications	2/25/13 	
1.  Ryan Steele	AWeber Communications	2/25/13 	
1.  Brian K. Jones	AWeber Communications	2/25/13 	
1.  Benjamin Krein	AWeber Communications	2/25/13 	
1.  Cliff Erson		2/26/13 	
1.  Booker Bense		2/27/13 	
1.  Charity Majors		2/27/13 	
1.  Jared Russell		2/27/13 	
1.  Iiro Uusitalo		2/27/13 	
1.  Ryan Walker	Rackspace	2/28/13 	
1.  Todd Bushnell		2/28/13 	
1.  BK Box		2/28/13 	
1.  Scott Stout		3/1/13 	
1.  Steffen Gebert		3/3/13 	
1.  John Cheng		3/3/13 	
1.  Jeremy Olliver		3/3/13 	
1.  Alexander Papaspyrou	adesso mobile solutions GmbH	3/4/13 	
1.  Stoyan Stoyanov	adesso mobile solutions GmbH	3/4/13 	
1.  Andreas Thielen	adesso mobile solutions GmbH	3/4/13 	
1.  Yves Vogl	adesso mobile solutions GmbH	3/4/13 	
1.  Brett Richardson		3/5/13 	
1.  Kevin Nuckolls	Banno, LLC	3/5/13 	
1.  Nic Grayson	Banno, LLC	3/5/13 	
1.  Luke Amdor	Banno, LLC	3/5/13 	
1.  Danny Lockard	Banno, LLC	3/5/13 	
1.  Thomas Wallace		3/5/13 	
1.  Ptah Dunbar		3/6/13 	
1.  Jonathan Asghar		3/6/13 	
1.  Brandon Sanders	AboutUs	3/7/13 	
1.  Aaron Brown		3/7/13 	
1.  Paul Oliver		3/7/13 	
1.  Alan Willis	Riot Games	3/7/13 	
1.  Dimitrios Verraros		3/8/13 	
1.  Arangamanikkannan Manickam		3/8/13 	
1.  David Bresnick		3/8/13 	
1.  Brett Weaver		3/8/13 	
1.  Drew Flower		3/8/13 	
1.  Charles Gregory Willis		3/8/13 	
1.  Owain Perry		3/9/13 	
1.  Alexander Sakharchuk		3/9/13 	
1.  Ameir Abdeldayem		3/9/13 	
1.  Robert Choi		3/10/13 	
1.  Gemini Agalo-os		3/10/13 	
1.  Alexander Galato		3/11/13 	
1.  Gabriel Klein		3/11/13 	
1.  Eric Richardson		3/12/13 	
1.  Steven Barre		3/13/13 	
1.  Paul Rossman	Google, Inc	3/14/13 	
1.  Riccardo Carlesso	Google, Inc	3/14/13 	
1.  Benson Kalahar	Google, Inc	3/14/13 	
1.  Rick Wright	Google, Inc	3/14/13 	
1.  Eric Johnson	Google, Inc	3/14/13 	
1.  Aaron Rice		3/15/13 	
1.  Radoslaw Gruchalski		3/15/13 	
1.  Matt Gleeson	Atlassian	3/18/13 	
1.  Will DeHaan	Atlassian	3/18/13 	
1.  Gabor Nagy		3/18/13 	
1.  Bryan Stearns		3/18/13 	
1.  Jose Diaz-Gonzalez		3/19/13 	
1.  Jean-Francois Theroux		3/19/13 	
1.  Christopher Stolfi		3/19/13 	
1.  Darrell Nash		3/19/13 	
1.  Sean Kane		3/20/13 	
1.  Patrick Leckey		3/20/13 	
1.  Michael Rose		3/20/13 	
1.  Pitr Vernigorov		3/20/13 	
1.  Capen Brinkley		3/20/13 	
1.  Tima Maslyuchenko		3/21/13 	
1.  Yvo van Doorn		3/21/13 	
1.  Tobias Wilken	cloudControl GmbH	3/21/13 	
1.  Mateusz Korszun	cloudControl GmbH	3/21/13 	
1.  Eric Chaves		3/21/13 	
1.  Peter Donald		3/21/13 	
1.  Remon Oldenbeuving		3/22/13 	
1.  Philip Cristiano		3/22/13 	
1.  Chris Streeter		3/24/13 	
1.  Kenneth Vetergaard		3/25/13 	
1.  Gert Kremer		3/25/13 	
1.  Peter de Rujiter	Springest	3/25/13 	
1.  Maarten Hoogendoorn	Springest	3/25/13 	
1.  Daniel Ryan		3/25/13 	
1.  Matthieu Launay	Criteo	3/26/13 	
1.  Jean-Baptiste Note	Criteo	3/26/13 	
1.  Daniel Koepke		3/26/13 	
1.  Neil Schelly	Dyn, Inc.	3/26/13 	
1.  David Miller	Dyn, Inc.	3/26/13 	
1.  Bill Young	Dyn, Inc.	3/26/13 	
1.  Phillip Goldenburg		3/27/13 	
1.  Faiz Kazi		3/31/13 	
1.  James Tucker	Google, Inc	4/1/13 	
1.  Marco Delaurenti	Google, Inc	4/1/13 	
1.  Sebastien Roccaserra		4/4/13 	
1.  Chendil Kumar Manoharan		4/4/13 	
1.  Jeremy Mauro	Criteo	4/5/13 	
1.  Joshua Levine		4/5/13 	
1.  Harley Alaniz	Lookout, Inc.	4/6/13 	
1.  Hiroaki Nakamura		4/8/13 	
1.  Leif Madsen	Thinking Phone Networks, Inc.	4/8/13 	
1.  Chris Sibbitt	Thinking Phone Networks, Inc.	4/8/13 	
1.  Christian Brideau	Thinking Phone Networks, Inc.	4/8/13 	
1.  Travis Hein	Thinking Phone Networks, Inc.	4/8/13 	
1.  Ming Chan		4/8/13 	
1.  Jamie Alessio		4/9/13 	
1.  Daichi Kamemoto		4/10/13 	
1.  David Groulx		4/10/13 	
1.  TAKEUCHI Go		4/11/13 	
1.  Alex Dergachev	Evolving Web Inc	4/11/13 	
1.  Suzanne Kennedy	Evolving Web Inc	4/11/13 	
1.  Sander Botman		4/15/13 	
1.  Julio Arias		4/15/13 	
1.  Alexander Wenzowski		4/16/13 	
1.  Pete Bristow		4/16/13 	
1.  Thorsten Klein		4/16/13 	
1.  Qingkun Liu		4/17/13 	
1.  Jonathan Cobb	Tout Industries	4/18/13 	
1.  Matt Lanier	Tout Industries	4/18/13 	
1.  Felix Roeser	Tout Industries	4/18/13 	
1.  Tom Hallett	Tout Industries	4/18/13 	
1.  Sam Gipe	Tout Industries	4/18/13 	
1.  Brandon Turner		4/20/13 	
1.  Mathias Lafeldt		4/20/13 	
1.  Matt Bower		4/21/13 	
1.  Zachary Patten	Lookout, Inc.	4/22/13 	
1.  Jim Hopp	Lookout, Inc.	4/22/13 	
1.  Zsolt Dollenstein		4/23/13 	
1.  Andrew Hollingsworth		4/24/13 	
1.  Benjamin Krueger		4/24/13 	
1.  Matt Thompson	Rackspace	4/25/13 	
1.  Hugh Saunders	Rackspace	4/25/13 	
1.  Harry Harrington	Rackspace	4/25/13 	
1.  Andy McCrae	Rackspace	4/25/13 	
1.  Chris Laco	Rackspace	4/25/13 	
1.  Bett Campbell	Rackspace	4/25/13 	
1.  Zack Feldstein	Rackspace	4/25/13 	
1.  Drew Rothstein		4/26/13 	
1.  Gaetano Santonastaso		4/26/13 	
1.  Tom Molin		4/26/13 	
1.  James Thompson		4/26/13 	
1.  Adam Stegman		4/26/13 	
1.  Robert Rehberg		4/26/13 	
1.  Amy Marco		4/27/13 	
1.  Chris Fordham		4/28/13 	
1.  Paolo Negri		4/29/13 	
1.  Jeremy Katz		4/29/13 	
1.  Troy Ready		4/30/13 	
1.  Jameson Lee		4/30/13 	
1.  Mehdi Lahmam		5/1/13 	
1.  Chandrashekar Seenappa		5/1/13 	
1.  Sander van Harmelen	Schuberg Philis 	5/1/13 	
1.  Matthew Hooker	Simple	5/1/13 	
1.  Robert Roose		5/1/13 	
1.  Peter Jihoon Kim	Irrational Industries	5/1/13 	
1.  Daniel Dao Quang Ming	Irrational Industries	5/1/13 	
1.  Arun K Thampi	Irrational Industries	5/1/13 	
1.  Paul Paradise	Socrata, Inc	5/1/13 	
1.  Chris Armstrong	Socrata, Inc	5/1/13 	
1.  David Chadwick Gibbons		5/1/13 	
1.  Chulki Lee	Aspera, Inc	5/1/13 	
1.  Christopher Markle	Aspera, Inc	5/1/13 	
1.  Jason Rutherford		5/1/13 	
1.  Peter Norton		5/2/13 	
1.  Walter Dal Mut		5/2/13 	
1.  Eric Sorenson		5/2/13 	
1.  Derrick Bryant		5/3/13 	
1.  Avrohom Katz		5/3/13 	
1.  Robert Postill		5/3/13 	
1.  Gabe Mulley	Hadapt, Inc	5/3/13 	
1.  Daniel Schauenberg		5/4/13 	
1.  James Turnbull		5/6/13 	
1.  Seren Thompson		5/7/13 	
1.  Solvi Pall Asgeirsson		5/7/13 	
1.  Dale Ragan	Moncai	5/7/13 	
1.  Eric Blevins	Moncai	5/7/13 	
1.  Kevin Landreth		5/8/13 	
1.  Ka-Wing Tam		5/10/13 	
1.  John Bellone Jr.		5/10/13 	
1.  Paolo Agostinetto		5/11/13 	
1.  Robert Coleman		5/11/13 	
1.  Ahmad Jemai		5/13/13 	
1.  Manuel Ryan		5/13/13 	
1.  Ben Somers		5/13/13 	
1.  Nate Fox		5/13/13 	
1.  Simon Coffey		5/14/13 	
1.  Andrea Bernardo Ciddio		5/14/13 	
1.  Maxim Doucet		5/14/13 	
1.  Martin Klein		5/14/13 	
1.  Jeremiah Wuenschel	Yahoo Inc.	5/14/13 	
1.  Deven Panchal	Yahoo Inc.	5/14/13 	
1.  Jeff Parrish	Yahoo Inc.	5/14/13 	
1.  Venkat Venkataraju	Yahoo Inc.	5/14/13 	
1.  Chris Wing	Yahoo Inc.	5/14/13 	
1.  Ittai Shadmon	Yahoo Inc.	5/14/13 	
1.  Itsik Figenblat	Yahoo Inc.	5/14/13 	
1.  Matthew Mencel		5/14/13 	
1.  Olaf Heydorn		5/16/13 	
1.  Bryan Stenson		5/16/13 	
1.  Holger Protzek		5/16/13 	
1.  Nilesh Bairagi		5/16/13 	
1.  Matt Clark		5/16/13 	
1.  Jan Nikolai Trzeszkowski		5/17/13 	
1.  Bernhard K. Weisshuhn		5/17/13 	
1.  Chris Reid		5/17/13 	
1.  Morgan Blackthorne		5/20/13 	
1.  Ken Miles		5/20/13 	
1.  James "Jim" Rosser, IV	Texas A&M University College of Architecture	5/20/13 	
1.  Derek Groh	Texas A&M University College of Architecture	5/20/13 	
1.  Benjamin Liles	Texas A&M University College of Architecture	5/20/13 	
1.  Kyle Morgan	Rackspace 	5/20/13 	
1.  Wilfred Hughes		5/21/13 	
1.  Jeff Anderson		5/21/13 	
1.  Brian Hatfield		5/21/13 	
1.  Guillermo Carrasco Hernandez		5/21/13 	
1.  James Sulinksi	MoPub	5/21/13 	
1.  Haydn Dufrene	MoPub	5/21/13 	
1.  Rob McQueen	MoPub	5/21/13 	
1.  Chris Snook	MoPub	5/21/13 	
1.  Christophe Arguel		5/22/13 	
1.  Sean Nolen		5/22/13 	
1.  Chetan Sarva		5/24/13 	
1.  Justin Ryan	Onelogin, Inc	5/24/13 	
1.  Stephen Touset	Onelogin, Inc	5/24/13 	
1.  Marcelo Serpa	Onelogin, Inc	5/24/13 	
1.  Nelson Enzo	Onelogin, Inc	5/24/13 	
1.  Elan Ruusamäe		5/24/13 	
1.  Marco Betti		5/26/13 	
1.  Jonathan Hitchcock	Yola	5/27/13 	
1.  Stefano Rivera	Yola	5/27/13 	
1.  Adrian Moisey	Yola	5/28/13 	
1.  Doug Beck	Yola	5/28/13 	
1.  John Tran		5/28/13 	
1.  Jesse Ahrens	CopperEgg	5/28/13 	
1.  Ross Dickey	CopperEgg	5/28/13 	
1.  Scott Johnson	CopperEgg	5/28/13 	
1.  Eric Anderson	CopperEgg	5/28/13 	
1.  Benjamin Bytheway		5/28/13 	
1.  Tehmasp Chaudhri		5/28/13 	
1.  Russell Teabeault		5/28/13 	
1.  Tim Ray		5/29/13 	
1.  Gavin Roy	MeetMe, Inc	5/30/13 	
1.  Peter Eisentraut	MeetMe, Inc	5/30/13 	
1.  Jennifer Fountain	MeetMe, Inc	5/30/13 	
1.  Kenny Furguson	MeetMe, Inc	5/30/13 	
1.  Michael Glaesemann	MeetMe, Inc	5/30/13 	
1.  Edward Robinson		6/1/13 	
1.  Baldur Gudbjornsson		6/1/13 	
1.  Jeffrey Jones		6/1/13 	
1.  Louis-Philippe Perron		6/5/13 	
1.  Victor Sollerhed		6/5/13 	
1.  Alvin Yik-ning Liang		6/5/13 	
1.  Cassiano Morgado de Aquino		6/5/13 	
1.  Brett Graves		6/6/13 	
1.  Mattew Collinge		6/6/13 	
1.  Nick Silkey	Rackspace	6/6/13 	
1.  Chris Stephan		6/6/13 	
1.  Peter Fern		6/6/13 	
1.  Kevin Bridges		6/6/13 	
1.  Peter Halliday		6/7/13 	
1.  Felix Bunemann		6/9/13 	
1.  Nanuk Krinner		6/10/13 	
1.  Robert Dyer		6/10/13 	
1.  Anthony Scalisi		6/11/13 	
1.  Ryan Hass		6/11/13 	
1.  Brad Beam		6/12/13 	
1.  Ean Rollings		6/13/13 	
1.  Ken Robertson		6/13/13 	
1.  Tony Chong		6/13/13 	
1.  Oliver Nicolaas Ponder		6/14/13 	
1.  Mikhail Kolesnik		6/16/13 	
1.  Sergey Khaladzinksi		6/16/13 	
1.  Tucker DeWitt		6/16/13 	
1.  Thomas Meeus		6/17/13 	
1.  Lin Lin		6/17/13 	
1.  Omar Vargas		6/17/13 	
1.  Domonkos Tomcsanyi	Boadree Innovations Kft.	6/17/13 	
1.  Prashant Nadarajan		6/18/13 	
1.  Eohyung Lee		6/18/13 	
1.  David Albrecht		6/18/13 	
1.  Nicholas Downs		6/19/13 	
1.  Mike Devine		6/19/13 	
1.  Thomas Cate	Rackspace 	6/18/13 	
1.  Ryan Richard	Rackspace 	6/18/13 	
1.  Matthew Thode	Rackspace	6/18/13 	
1.  Chris Aumann		6/20/13 	
1.  Eric Wunderlin		6/21/13 	
1.  Georgi Markov		6/21/13 	
1.  Sjoerd Mulder		6/21/13 	
1.  Benjamin Knauss		6/21/13 	
1.  Erik Gustavson	Bitium, Inc	6/21/13 	
1.  Prashant Nadarajan	Bitium, Inc	6/21/13 	
1.  Walter Schiessberg		6/24/13 	
1.  Vasily Mikhaylichenko 		6/24/13 	
1.  William Anthony Rhodes Jr		6/24/13 	
1.  Adam Wayne		6/24/13 	
1.  Max Manders 	Cloudreach	6/24/13 	
1.  Justin Stallard		6/25/13 	
1.  Nelson Chen		6/26/13 	
1.  Eric Sproul	OmniTI	6/19/13 	
1.  Andrew Macgregor 		6/27/13 	
1.  Jeffrey Damick		6/26/13 	
1.  Daniel Williams		6/27/13 	
1.  Bruce Li		6/27/13 	
1.  Satoshi Akama		6/28/13 	
1.  Dave Stern		6/28/13 	
1.  David Andrew		6/28/13 	
1.  Anthony Burns		6/29/13 	
1.  Michael Ballantyne		6/28/13 	
1.  Ewan McDougall		7/1/13 	
1.  Matt Patterson		7/1/13 	
1.  Ivan Puzyrevskiy		7/2/13 	
1.  Stefano Tortarolo		7/3/13 	
1.  Christopher MacNaughton		7/3/13 	
1.  Skye Book		7/3/13 	
1.  Mark Butcher		7/4/13 	
1.  Nick Morgan 	Heart of Sales LLC DBA Ace of Sales 	7/4/13 	
1.  Ryan Schlesinger	Heart of Sales LLC DBA Ace of Sales 	7/4/13 	
1.  Kevin Patrick Pullin II		7/5/13 	
1.  Colin Woodcock	NetSrv Consulting Ltd	7/7/13 	
1.  Joshua Tobin		7/8/13 	
1.  James Cuzella		7/8/13 	
1.  Michael John Huot Jr.		7/9/13 	
1.  William Albenzi		7/9/13 	
1.  Matas Veitas		7/10/13 	
1.  NagaLakshmi N		7/10/13 	
1.  Evan Michael Kinney		7/11/13 	
1.  Adam Lane		7/11/13 	
1.  Rafael Colton		7/11/13 	
1.  Julien Phalip		7/11/13 	
1.  Matthew Savage		7/11/13 	
1.  Koseki Kengo		7/11/13 	
1.  Gregory Palmier		7/12/13 	
1.  Alain O'Dea		7/12/13 	
1.  Peter Hoellig	PROS, Inc. a Delaware Corporation	7/12/13 	
1.  Vladimir Skubriev		7/12/13 	
1.  Ryan Stephens 	AURIN Project -Faculty of Architecture, Building and Planning 	7/12/13 	
1.  Martin Tomko 	AURIN Project -Faculty of Architecture, Building and Planning 	7/12/13 	
1.  Christopher Bayliss 	AURIN Project -Faculty of Architecture, Building and Planning 	7/12/13 	
1.  Peter Ellingsen 	AURIN Project -Faculty of Architecture, Building and Planning 	7/12/13 	
1.  Chris Pettit 	AURIN Project -Faculty of Architecture, Building and Planning 	7/12/13 	
1.  Jörg Thalheim		7/12/13 	
1.  Zac Hallett		7/12/13 	
1.  Emanuele Zattin		7/11/13 	
1.  Daniel Steen		7/12/13 	
1.  Ronnie Taylor		7/13/13 	
1.  Danny Guinther		7/14/13 	
1.  Michael Vitale		7/16/13 	
1.  Nicholas Ethier		7/16/13 	
1.  Steve Poe	Onlife Health Inc 	7/17/13 	
1.  Craig Menning		7/17/13 	
1.  Antoni Baranski	Roblox Inc.	7/17/13 	
1.  John Landahl		7/18/13 	
1.  Rudy Grigar		7/19/13 	
1.  Katsuma Ito		7/19/13 	
1.  Andrew Wyatt	Onlife Health Inc	7/19/13 	
1.  Naoki AINOYA		7/21/13 	
1.  David Giesberg		7/21/13 	
1.  Luke Hoschke		7/21/13 	
1.  Myles Steinhauser		7/22/13 	
1.  Kyle Rames	Rackspace	7/23/13 	
1.  Chris Snell	Rackspace	7/23/13 	
1.  Jason Roelofs		7/23/13 	
1.  Hugo Trippaers		7/24/13 	
1.  Mark Friedgan		7/24/13 	
1.  Matthew Hopkins		7/24/13 	
1.  Eddie Zaneski		7/24/13 	
1.  Maxwell Robett Dietz		7/24/13 	
1.  Simon Robson		7/25/13 	
1.  Dan Bachelder		7/26/13 	
1.  Matthew Farmer		7/26/13 	
1.  Thomas Neal Cravey		7/26/13 	
1.  Ross Timson		7/29/13 	
1.  Donald Stufft		7/28/13 	
1.  Gilles Cornu		7/28/13 	
1.  Kenichi Saita		7/28/13 	
1.  Ivan Tanev		7/27/13 	
1.  Chris Gallimore		7/26/13 	
1.  Sonny Garcia		7/26/13 	
1.  Alexis Midon		7/26/13 	
1.  Brandon Henry		7/29/13 	
1.  Jordan Wesolowski		7/29/13 	
1.  Christopher Brinley		7/29/13 	
1.  Nimesh Subramanian	Cerner	7/29/13 	
1.  Eric Hartmann		7/29/13 	
1.  Kevin Rochford		7/30/13 	
1.  Jon San Miguel		7/30/13 	
1.  Tommy Fotak		7/31/13 	
1.  Nicholas Hatch		8/1/13 	
1.  Raf Geens		8/6/13 	
1.  Thomas Bell		8/6/13 	
1.  Braden Wright		8/6/13 	
1.  Johnny Tan		8/6/13 	
1.  Yvonne Beumer	Cloudreach	8/12/13 	
1.  Ben House		8/9/13 	
1.  Joe Fitzgerald		8/12/13 	
1.  Peter Hessler		8/13/13 	
1.  Nicholas Russell		8/13/13 	
1.  Brian Golf		8/13/13 	
1.  Adam Kunk		8/13/13 	
1.  Sandy Vanderbleek		8/13/13 	
1.  Lance French		8/13/13 	
1.  Jeff Hagadom		8/14/13 	
1.  George Miranda		8/16/13 	
1.  Evan Gilman		8/19/13 	
1.  Nenad Petronijevic		8/19/13 	
1.  Daniel Spilker 	CoreMedia AG	7/31/13 	 	
1.  Felix Simmendinger	CoreMedia AG	7/31/13 	
1.  Eike Thienemann-Dehde	CoreMedia AG	7/31/13 	 	
1.  Christopher Hass	CoreMedia AG	7/31/13 	
1.  Daniel Zabel	CoreMedia AG	7/31/13 	
1.  Ryan Munson	Taos Mountain, Inc.	7/31/13 	
1.  Tim Fischbach		8/20/13 	
1.  Chance Zibolski		8/20/13 	
1.  Kazuki Akamine		8/20/13 	
1.  David Wittman		8/20/13 	
1.  Brian Whipple	PROS, Inc. a Delaware Corporation	8/14/13 	
1.  Michael Jensen	PROS, Inc. a Delaware Corporation	8/14/13 	
1.  Asanka Samaraweera	PROS, Inc. a Delaware Corporation	8/14/13 	
1.  Christian Vozar	Belly Inc	8/20/13 	
1.  Darby Frey	Belly Inc	8/20/13 	
1.  Matthew Herscovitch	Identive Group	8/20/13 	
1.  Mark Butcher	Identive Group	8/20/13 	
1.  Luke Bradbury	University of Derby	8/28/13 	
1.  Dan Webb	University of Derby	8/28/13 	
1.  Alastair Firth		8/23/13 	
1.  Jesse Adams		8/28/13 	
1.  Matt Alexander		8/28/13 	
1.  Jason Vanderhoof		8/26/13 	
1.  Lianping Chen		8/26/13 	
1.  Christoph Bunte		8/26/13 	
1.  Yvonne Lam		8/28/13 	
1.  Mark Cornick	TeamSnap	8/29/13 	
1.  Justin Clarke	Social Ally Pty Ltd	8/29/13 	
1.  H Wade Minter	TeamSnap	8/29/13 	
1.  Kyle Ries	TeamSnap	8/29/13 	
1.  Phillip Hutchins		8/30/13 	
1.  Artem Kornienko		8/30/13 	
1.  Ulf Mansson	Recorded Future	9/2/13 	
1.  Sam Crang		8/31/13 	
1.  Jorge Acosta Goszczynski		9/3/13 	
1.  Lysenko Kostiantyn		9/4/13 	
1.  Phil Sturgeon		9/4/13 	
1.  Kamil Bednarz		9/4/13 	
1.  Travis Petticrew		9/4/13 	
1.  Peter Walz		8/29/13 	
1.  Jeffrey Utter		9/4/13 	
1.  Martin Cozzi		9/4/13 	
1.  Andrew Thompson		9/4/13 	
1.  Thomas von Schwerdtner		9/4/13 	
1.  William Dierkes		9/4/13 	
1.  Robin Ricard		9/5/13 	
1.  Ben Longden		9/5/13 	
1.  Alex Denvir	Protec Innovations Ltd.	9/5/13 	
1.  Martin Meredith	Protec Innovations Ltd.	9/5/13 	
1.  Phil Thompson	Protec Innovations Ltd.	9/5/13 	
1.  Alejandro Blanco		9/5/13 	
1.  Adrian Moisey		9/5/13 	
1.  Alex Zorin		9/5/13 	
1.  Robert Schulze		9/5/13 	
1.  Wei Liang		9/5/13 	
1.  Jon Torresdal		9/5/13 	
1.  Sergii Golovatiuk		9/6/13 	
1.  Mark O'Keefe		9/6/13 	
1.  Brint O'Heam		9/6/13 	
1.  Jim Myhrberg		9/7/13 	
1.  James FitzGibbon		9/8/13 	
1.  Isbaran Akcayir		9/9/13 	
1.  Sylvain Tisso	Ecodev Sarl	9/9/13 	
1.  Fabien Udriot	Ecodev Sarl	9/9/13 	
1.  Adrien Crivelli	Ecodev Sarl	9/9/13 	
1.  Yoshanda Shin		9/10/13 	
1.  Christo De Lange		9/10/13 	
1.  Arthur Freyman		9/10/13 	
1.  Martin Walton		9/10/13 	
1.  Matthew Brennan		9/10/13 	
1.  Luis Ricardo Malheiros		9/11/13 	
1.  Amir Kadivar		9/11/13 	
1.  Davanum Srinivas		9/12/13 	
1.  Jesse Pretorius		9/12/13 	
1.  Denis Corol		9/12/13 	
1.  Yevgen Kovalienia		9/12/13 	
1.  Ben Hines		9/13/13 	
1.  Muneyuki Noguchi		9/14/13 	
1.  Myers Carpenter		9/16/13 	
1.  Mathieu Allaire		9/16/13 	
1.  Michael Stucki		9/17/13 	
1.  Kevin Webster		9/17/13 	
1.  Conor McDermottroe		9/17/13 	
1.  Naoya Nakazawa		9/17/13 	
1.  Mark Gibbons	Nordstrom	9/17/13 	
1.  Matthew Moore		9/17/13 	
1.  Ingo Kampe	kreuzwerker GmbH	9/18/13 	
1.  Robert Conrad	kreuzwerker GmbH	9/18/13 	
1.  Daniel Meisen	kreuzwerker GmbH	9/18/13 	
1.  Alexander Dall	kreuzwerker GmbH	9/18/13 	
1.  Jan Nabbefeld	kreuzwerker GmbH	9/18/13 	
1.  Joern Barthel	kreuzwerker GmbH	9/18/13 	
1.  Harvey Bandana	Nordstrom	9/18/13 	
1.  Ben Holley		9/18/13 	
1.  Yuji Takaesu		9/18/13 	
1.  Colin Burn-Murdoch		9/20/13 	
1.  Andrius Marcinkevicius		9/20/13 	
1.  Alan Bryan	Central Desktop	9/18/13 	
1.  Craig Lewis	Central Desktop	9/18/13 	
1.  Saku Laitinen	Siili Solutions	9/19/13 	
1.  Denis Barishev	Twiket LTD	9/23/13 	
1.  Sam Orlov	Twiket LTD	9/23/13 	
1.  Jarek Gawor	IBM	9/23/13 	
1.  Anthony Elder	IBM	9/23/13 	
1.  Michael C Thompson	IBM	9/23/13 	
1.  Jeremy Hughes	IBM	9/23/13 	
1.  Igor Rodionov		9/23/13 	
1.  Gabor Garami		9/24/13 	
1.  Iulia Banghea		9/24/13 	
1.  Paul Dunnavant		9/24/13 	
1.  Alex Heneveld	Cloudsoft Corp.	9/25/13 	
1.  Jordi Massaguer Pla		9/25/13 	
1.  Richard Downer	Cloudsoft Corp.	9/25/13 	
1.  Roger Hu		9/25/13 	
1.  Dominic St-Jacques		9/25/13 	
1.  Mahmoud Abdelkader		9/26/13 	
1.  Takahiro Himura		9/26/13 	
1.  Aled Sage	Cloudsoft Corp.	9/25/13 	
1.  Andrew Kennedy	Cloudsoft Corp.	9/25/13 	
1.  Sam Corbett	Cloudsoft Corp.	9/25/13 	
1.  Trevor Leybourne	MYOB NZ Limited	9/26/13 	
1.  Greg Zapp	MYOB NZ Limited	9/26/13 	
1.  Bo Ma	MYOB NZ Limited	9/26/13 	
1.  Dmitry Lavrinenko		9/27/13 	
1.  Vitaly Shishlyannikov		9/27/13 	
1.  Jonathan Mickle		9/27/13 	
1.  Scott Hain Jr		9/27/13 	
1.  Ethan Fremen		9/29/13 	
1.  Daniel O'Conner		9/29/13 	
1.  Bill Wiens		9/30/13 	
1.  Jeroen Grusebroek	Mollie B.V.	9/30/13 	
1.  Morton Jonuschat		9/30/13 	
1.  Bentrand Paquet		10/1/13 	
1.  Christoph Hartmann		10/1/13 	
1.  Okezie Eze		10/1/13 	
1.  Christopher Dwan		10/1/13 	
1.  Carl Schmidt	Unbounce	10/1/13 	
1.  Aaron Oman	Unbounce	10/1/13 	
1.  Chris Spicer	Unbounce	10/1/13 	
1.  Jimmy Zheng	Unbounce	10/1/13 	
1.  Josh Blancett		10/1/13 	
1.  Stephen Romney	Shutl Ltd. 	10/2/13 	
1.  James Wilford	Shutl Ltd. 	10/2/13 	
1.  Sam Phillips	Shutl Ltd. 	10/2/13 	
1.  Yomi Colledge	Shutl Ltd. 	10/2/13 	
1.  Marco Nenciarini		10/2/13 	
1.  Jake Herbst		10/2/13 	
1.  Kawahara Masashi		10/2/13 	
1.  Ilan Rabinovitch	Ooyala, Inc.	10/3/13 	
1.  Garry Polley		10/3/13 	
1.  Akshay Karle		10/3/13 	
1.  Pascal Gelinas	Nu Echo	10/3/13 	
1.  Salim Semaoune		10/3/13 	
1.  August Schwer		10/4/13 	
1.  Sam Adams		10/7/13 	
1.  Niels Kristensen		10/7/13 	
1.  Aliaksei Kliuchnikau		10/7/13 	
1.  Theofilos Papapanagiotou		10/7/13 	
1.  Mike Rossetti	Our Film Festival (dba Fandor)	10/7/13 	
1.  Victor Lin		10/8/13 	
1.  Tyler Kellen		10/8/13 	
1.  Baba Buehler		10/8/13 	
1.  Matt Clifton		10/8/13 	
1.  Daniel Babel	Ooyala, Inc.	10/9/13 	
1.  Jurgen Philippaerts	Ooyala, Inc.	10/9/13 	
1.  Josh Toft	Ooyala, Inc.	10/9/13 	
1.  Tobias Maier	BauCloud GmbH	10/9/13 	
1.  Ryota Arai		10/9/13 	
1.  Kyle Kelley		10/10/13 	
1.  Jaroslav Barton		10/10/13 	
1.  Sam Pointer		10/10/13 	
1.  Sebastian Guevara		10/10/13 	
1.  Paul Welch	Squaremouth Inc	10/10/13 	
1.  Peter Georgantas		10/10/13 	
1.  Karla Jacobsen		10/10/13 	
1.  Ryan S Brown		10/10/13 	
1.  Richard Manyanza		10/11/13 	
1.  Guilhem Lettron	Optiflows	10/11/13 	
1.  Ludovic Havel	Optiflows	10/11/13 	
1.  Jean Rouge		10/11/13 	
1.  Devon Jones		10/11/13 	
1.  Matthew Kasa		10/11/13 	
1.  James Moorhouse		10/12/13 	
1.  Christopher Grim		10/12/13 	
1.  Ryan Frantz		10/14/13 	
1.  Shrikant Patnaik	General Sensing LTD	10/10/13 	
1.  Aaron Valade	General Sensing LTD	10/10/13 	
1.  Chris Jerdonek		10/13/13 	
1.  EJ Ciramella	Rapid7	10/14/13 	
1.  Brandon Turner	Rapid7	10/14/13 	
1.  Chris Smtih	Rapid7	10/14/13 	
1.  Ben Tomasini		10/14/13 	
1.  Evan Todd		10/15/13 	
1.  Alex Shadrin		10/15/13 	
1.  Mart Karu		10/15/13 	
1.  Russell Cardullo		10/15/13 	
1.  John Tran		10/15/13 	
1.  Alex Koch		10/15/13 	
1.  Jonathan Regeimbal		10/15/13 	
1.  James Walker		10/16/13 	
1.  Justin Dugger		10/16/13 	
1.  Dustin Collins		10/16/13 	
1.  Matthew Boedicker		10/17/13 	
1.  John Deatherage		10/17/13 	
1.  Aaron Jensen		10/17/13 	
1.  Olksandr Slynko		10/17/13 	
1.  Emanuele Rocca		10/18/13 	
1.  Antonio Fernandez Vara		10/18/13 	
1.  Mickhail Zholobov		10/18/13 	
1.  Daniel Wallace	Rackspace	10/18/13 	
1.  Christian Fischer		10/18/13 	
1.  Silviu Dicu		10/18/13 	
1.  William Pietri		10/19/13 	
1.  Daniel Tracy		10/21/13 	
1.  Ashish Shinde		10/22/13 	
1.  Mathew Hoyle	Deployable LTD	10/22/13 	
1.  Leonardo Leite	 	10/22/13 	
1.  Michael Dore		10/22/13 	
1.  Hannes Van De Vreken		10/22/13 	
1.  Mevan Samaratunga		10/22/13 	
1.  Adam Enger		10/22/13 	
1.  Peter Jönsson	Klarna	10/23/13 	
1.  Carl Loa Odin	Klarna	10/23/13 	
1.  Olle Lundberg	Klarna	10/23/13 	
1.  Pat Downey		10/24/13 	
1.  Max Lincoln		10/24/13 	
1.  Pavel Brylov		10/24/13 	
1.  Sam Clements		10/25/13 	
1.  Gabriel Mazetto		10/25/13 	
1.  Cory Gunterman	Nike, Inc.	10/25/13 	
1.  Justin Redd	Nike, Inc.	10/25/13 	
1.  Dave Palomino	Nike, Inc.	10/25/13 	
1.  Tom Luce	Nike, Inc.	10/25/13 	
1.  Shawn Turpin	Nike, Inc.	10/25/13 	
1.  Ed Tretyakov		10/27/13 	
1.  Frank Breedijk	Schuberg Phillis B.V.	10/28/13 	
1.  Henry Finucane		10/30/13 	
1.  Thomas de Grenier de Latour		10/30/13 	
1.  Andrey Chernih		10/30/13 	
1.  Matt Wormley		10/30/13 	
1.  Maciej Galkiewicz		10/31/13 	
1.  Makiko Nomura		11/1/13 	
1.  Cheah Chu Yeow	Irrational Industries, Inc.	11/1/13 	
1.  Christian Paredes	Irrational Industries, Inc.	11/1/13 	
1.  Rafael Kolless		11/2/13 	
1.  Zsolt Takacs		11/2/13 	
1.  Tobias Schmidt	SoundCloud Ltd.	11/5/13 	
1.  Frederick Jaeckel	SoundCloud Ltd.	11/5/13 	
1.  Matthias Rampke	SoundCloud Ltd.	11/5/13 	
1.  Daman Yang	SoundCloud Ltd.	11/5/13 	
1.  Ben Kochie	SoundCloud Ltd.	11/5/13 	
1.  Alexander Grosse	SoundCloud Ltd.	11/5/13 	
1.  Allan Beaufour	Project Florida	11/5/13 	
1.  Jow Crobak	Project Florida	11/5/13 	
1.  Derek Groh		11/5/13 	
1.  David Shawley		11/5/13 	
1.  Jason Faulkner		11/5/13 	
1.  Cheryl Ainoa	Intuit	11/6/13 	
1.  Thomas Bishop	Intuit	11/6/13 	
1.  Jeffrey Mendoza		11/6/13 	
1.  Munirathnam Srikanth	ComputeNext	11/6/13 	
1.  Sergio Patino		11/6/13 	
1.  Andrew Caldwell		11/6/13 	
1.  Alex Derzhi		11/7/13 	
1.  Olivier Biesmans		11/7/13 	
1.  Gabriel Rosendorf	The Weather Companies	11/8/13 	
1.  Nathaniel Eliot		11/9/13 	
1.  Thibaut Notteboom		11/10/13 	
1.  Walter Huf		11/11/13 	
1.  David Larken Nolen		11/11/13 	
1.  Makana Greenwell		11/12/13 	
1.  Mathew Hartley		11/12/13 	
1.  Julie Rice	PTC Inc	11/13/13 	
1.  Matt Welch	PTC Inc	11/13/13 	
1.  Jonathan Bass	PTC Inc	11/13/13 	
1.  Joe Rocklin		11/14/13 	
1.  Zaininnari		11/14/13 	
1.  Jean Mertz		11/18/13 	
1.  Gleb Borisov		11/19/13 	
1.  Curtis Stewart		11/19/13 	
1.  Jim Park	RamTank Inc	11/19/13 	
1.  Pierre Ynard	Criteo	11/19/13 	
1.  Sergey Balbeko		11/20/13 	
1.  Igor Serko		11/20/13 	
1.  Jason Giedymin		11/20/13 	
1.  Luca Pradovera		11/20/13 	
1.  Jason Giedymin		11/20/13 	
1.  Shaun Rowe		11/21/13 	
1.  Chad Cloes	Intuit	11/21/13 	
1.  Rick Mendes	Intuit	11/21/13 	
1.  Grant Hoffman	Intuit	11/21/13 	
1.  Capen Brinkley	Intuit	11/21/13 	
1.  Kevin Young	Intuit	11/21/13 	
1.  Walter Askew IV		11/22/13 	
1.  Spencer Smith		11/23/13 	
1.  Spencer Smith		11/23/13 	
1.  Connor Goodwolf		11/23/13 	
1.  Seiji Komatsu		11/24/13 	
1.  Steve Domin	GoCardless	11/24/13 	
1.  Milos Gajdos	GoCardless	11/24/13 	
1.  Harry Marr	GoCardless	11/24/13 	
1.  Komatsu Seiji		11/25/13 	
1.  Gokulnath Manakkattil		11/26/13 	
1.  Joel Moss		11/27/13 	
1.  Drew J. Sonne		11/30/13 	
1.  Sascha Mollering	ZANOX AG	11/30/13 	
1.  Boris Komraz		12/1/13 	
1.  Mark O'Connor		12/1/13 	
1.  Ivan Larionov		12/2/13 	
1.  Pierre Carrier		12/2/13 	
1.  Joe A. Kemp	ARINC	12/3/13 	
1.  Douglas Mendizabal		12/3/13 	
1.  Tejay Cardon	Lockheed Martin Corporation	12/3/13 	
1.  David Deal	Lockheed Martin Corporation	12/3/13 	
1.  Jason Loveland	Lockheed Martin Corporation	12/3/13 	
1.  Friedrich Clausen		12/4/13 	
1.  Paul Kehrer		12/4/13 	
1.  Stephan Renatus		12/5/13 	
1.  Abhijit Hiremagalur		12/5/13 	
1.  Wojciech Oledzki		12/5/13 	
1.  Johannes Plunien		12/7/13 	
1.  Benjamin Demaree		12/8/13 	
1.  Friedel Ziegelmayer		12/13/13 	
1.  Jason Vervlied		12/13/13 	
1.  Fabian Lee		12/15/13 	
1.  Tino Breddin		12/16/13 	
1.  Cameron Cope	Brightcove	12/16/13 	
1.  Jason Perry	Brightcove	12/16/13 	
1.  Eric Moakley	Brightcove	12/16/13 	
1.  Joshua Spiewak	Brightcove	12/16/13 	
1.  John Schectman	Brightcove	12/16/13 	
1.  Keegan Holley		12/16/13 	
1.  James La Spada		12/17/13 	
1.  Jesué Sousa Cunha Junior		12/17/13 	
1.  Dan Rathbone		12/17/13 	
1.  Jay Geeseman		12/19/13 	
1.  David Bernick		12/20/13 	
1.  Primož Verdnik		12/20/13 	
1.  Yavor Nikolov		12/26/13 	
1.  Joseph C. Stump	Sprint.ly, Inc	12/27/13 	
1.  Justin T. Abrahms	Sprint.ly, Inc	12/27/13 	
1.  Theodore Chuong Nordsieck		12/29/13 	
1.  Thomas Noonan II		12/30/13 	
1.  Coman Ioan Andrei		12/30/13 	
1.  Steven Geerts	Schuberg Phillis B.V.	1/2/14 	
1.  Scott Russell		1/3/14 	
1.  Lothar Wieske		1/3/14 	
1.  Paul Czarkowski		1/3/14 	
1.  Ramil Lim		1/3/14 	
1.  Jeff Byrnes		1/3/14 	
1.  Christopher James Saylor		1/4/14 	
1.  Gary Cao		1/6/14 	
1.  Christopher William Pernicano		1/6/14 	
1.  Emmanuel Idi		1/6/14 	
1.  Reid Beels		1/7/14 	
1.  Anthony LoBono		1/8/14 	
1.  Barthélemy Vessemont		1/10/14 	
1.  Michael Holtzman		1/10/14 	
1.  Tristan O'Neil	Cramer Development	1/10/14 	
1.  Brian Cobb	Cramer Development	1/10/14 	
1.  Brett Chalupa	Cramer Development	1/10/14 	
1.  Dan Volkens	Cramer Development	1/10/14 	
1.  Ryan Keairns	Cramer Development	1/10/14 	
1.  Nikhil Benesch		1/12/14 	
1.  Christian Höltje		1/13/14 	
1.  Alexander C Corvin		1/17/14 	
1.  Samuel Chambers		1/18/14 	
1.  Cheah Chu Yeow		1/18/14 	
1.  Kazuki Saito		1/18/14 	
1.  Pete Richards		1/19/14 	
1.  Jimmy McCrory		1/19/14 	
1.  Olivier Dolbeau		1/20/14 	
1.  Andrew Brown	BlackBerry, Inc.	1/20/14 	
1.  Phil Oliva	BlackBerry, Inc.	1/20/14 	
1.  Dave Urschatz	BlackBerry, Inc.	1/20/14 	
1.  Ishtiaq Ahmed		1/25/14 	
1.  Caleb Land		1/26/14 	
1.  Charles B Johnson		1/26/14 	
1.  Diego Rodriguez		1/27/14 	
1.  Nitin Mohan		1/27/14 	
1.  Szymon Szypulski		1/29/14 	
1.  Jaime Gil de Sagredo		1/29/14 	
1.  Jose Luis Ferrer Riera		1/29/14 	
1.  Yury Velikanau		1/29/14 	
1.  Jeroen Jacobs		1/30/14 	
1.  W. Hart Hoover	Rackspace	2/3/14 	
1.  Jerry Richardson	Disruptive Ventures, Inc	2/4/14 	
1.  Brian Dwyer		2/4/14 	
1.  Aaron O'Mullan	FriendCode, Inc	2/5/14 	
1.  Jean-Baptiste Dalido		2/6/14 	
1.  Juri Timoshin		2/6/14 	
1.  Pascal Laporte		2/6/14 	
1.  Steven Cummings	Cerner Innovation Inc	2/6/14 	
1.  Pascal Laporte		2/6/14 	
1.  Mick Brooks		2/7/14 	
1.  Aurélien Noce		2/7/14 	
1.  Charlie Huggard	Cerner Innovation Inc	2/11/14 	
1.  Matthias Arnason	Engine Yard	2/12/14 	
1.  Bryan Taylor		2/12/14 	
1.  Michael Dillion		2/17/14 	
1.  Seth Kingry		2/18/14 	
1.  Wesley David DeCesare	Crux Hosted Services	2/18/14 	
1.  Kent Shultz		2/18/14 	
1.  Adam Durana		2/21/14 	
1.  Jacob McCann		2/21/14 	
1.  Andriy Tyurnikov		2/21/14 	
1.  Anton Koldaev		2/21/14 	
1.  Matthew Rathbone		2/21/14 	
1.  Egor Medvedev		2/23/14 	
1.  Eric Tucker	Blue Spurs	2/24/14 	
1.  Tomas Gutierrez		2/24/14 	
1.  Jordan Burke		2/25/14 	
1.  Zvi Effron		2/25/14 	
1.  Pranay Manwatkar		2/26/14 	
1.  Kaspars Mickevics		2/26/14 	
1.  Roman Gorodeckij		2/27/14 	
1.  Matthew Baxa		2/27/14 	
1.  Maxime Caumartin		2/27/14 	
1.  Brandon Raabe		2/28/14 	
1.  Alan Grosskurth		2/28/14 	
1.  Nathan Milford		2/28/14 	
1.  Jacob Vosmaer	GitLab.com	3/1/14 	
1.  Job van der Voort	GitLab.com	3/1/14 	
1.  Marin Jankovski	GitLab.com	3/1/14 	
1.  Martin Glaß		3/1/14 	
1.  Sergey Sergeev		3/1/14 	
1.  Marshall Ian Farmer		3/2/14 	
1.  Markus Schabel		3/3/14 	
1.  Torben Knerr		3/4/14 	
1.  Pavel Sadikov		3/5/14 	
1.  David King		3/7/14 	
1.  Charles Guenther	Yelp	3/7/14 	
1.  Kris Wehner	Yelp	3/7/14 	
1.  Brian Fletcher	Workday	3/10/14 	
1.  Brad Pokorny	IBM	3/10/14 	
1.  John Warren	IBM	3/10/14 	
1.  Lance Bragstad	IBM	3/10/14 	
1.  Luis Garcia	IBM	3/10/14 	
1.  Mark Vanderwiel	IBM	3/10/14 	
1.  Mathew Odden	IBM	3/10/14 	
1.  Andrew Coulton		3/11/14 	
1.  Andrew Ordiales		3/11/14 	
1.  Will Hattingh		3/12/14 	
1.  Eohyung Lee		3/13/14 	
1.  Matthew Zito	BMC Software Inc	3/13/14 	
1.  Nick Galbreath		3/13/14 	
1.  Thomas Duckering		3/14/14 	
1.  Stanley Halka		3/14/14 	
1.  Michael Morris		3/14/14 	
1.  Gavin Montague	itison	3/14/14 	
1.  John Daniels	itison	3/14/14 	
1.  Matthias Endler		3/17/14 	
1.  Greg Albrecht	OnBeep, Inc.	3/19/14 	
1.  Andy Issacson	OnBeep, Inc.	3/19/14 	
1.  Ben Graver	OnBeep, Inc.	3/19/14 	
1.  Jim Qin	OnBeep, Inc.	3/19/14 	
1.  Carlos Vinueza	OnBeep, Inc.	3/19/14 	
1.  Benson Miller	Level 11 Consulting	3/19/14 	
1.  Nik Ormseth	Level 11 Consulting	3/19/14 	
1.  James Francis	Level 11 Consulting	3/19/14 	
1.  Kevin Rivers	Level 11 Consulting	3/19/14 	
1.  Michael Dellanoce		3/20/14 	
1.  Joey Line		3/21/14 	
1.  Nick Lopez		3/22/14 	
1.  Jason Byck		3/23/14 	
1.  Ian Neubert		3/25/14 	
1.  Brandon Taylor Groves		3/25/14 	
1.  Sean Walberg		3/25/14 	
1.  Matthijs Wijers		3/26/14 	
1.  Tensibai Zhaoying		3/26/14 	
1.  Michael Chletso		3/27/14 	
1.  Joseph Korkames		3/27/14 	
1.  Matthew Juszczak		3/27/14 	
1.  Hongbin Lu		3/27/14 	
1.  Ryan Lewon		3/28/14 	
1.  Tiru Srikantha		3/29/14 	
1.  Calvin Worsnup		3/31/14 	
1.  Andres More		4/1/14 	
1.  Joe Richards		4/1/14 	
1.  Mikael Henriksson		4/2/14 	
1.  Benjamin Dalton LeMasurier		4/2/14 	
1.  Dirk Moermans		4/3/14 	
1.  Pavel Yudin		4/4/14 	
1.  Ed Neville	Linaro Limited	4/4/14 	
1.  Andrew McDermott	Linaro Limited	4/4/14 	
1.  Ron Nandy	Linaro Limited	4/4/14 	
1.  Florian Holzhauer		4/4/14 	
1.  Joshua Yotty		4/4/14 	
1.  Narendra V Dharmavarapu		4/4/14 	
1.  Brian Wilson Leake		4/6/14 	
1.  John Northrup		4/7/14 	
1.  Yoichi Isozaki		4/7/14 	
1.  Jordan Evans		4/8/14 	
1.  Oliver Kohl		4/9/14 	
1.  Craig Monson		4/10/14 	
1.  Rob Brown		4/10/14 	
1.  Alexander Myasnikov		4/11/14 	
1.  Matthew Hodgkins		4/12/14 	
1.  Aaron Quint		4/12/14 	
1.  Jaewoo Kim		4/17/14 	
1.  Vasiliy Tolstov		4/17/14 	
1.  Ryan Moe		4/18/14 	
1.  G. Panula		4/21/14 	
1.  Chris Antenesse		4/21/14 	
1.  Lloyd Chan		4/22/14 	
1.  Satoshi Tanaka		4/22/14 	
1.  Tim Heckman		4/24/14 	
1.  Trevor Lauder		4/25/14 	
1.  Nathan Haneysmith	Nordstrom	4/25/14 	
1.  Aaron Lane		4/26/14 	
1.  Bao Nguyen		4/27/14 	
1.  Salvatore Poliandro III		4/28/14 	
1.  Eric Zhoe		4/29/14 	
1.  Alex Kahn		4/29/14 	
1.  Brendan Murtagh		4/29/14 	
1.  Tyler Cipriani		4/29/14 	
1.  Syunsuke Komma	WESEEK	4/29/14 	
1.  Yuki Takei	WESEEK	4/29/14 	
1.  Trevor Bramwell		5/1/14 	
1.  Robert Tarrall		5/1/14 	
1.  Josh Reichardt		5/1/14 	
1.  Trevor Lauder	Intuit	5/1/14 	
1.  Jake Plimack		5/2/14 	
1.  Brian D Clark		5/3/14 	
1.  Roman Chukh		5/4/14 	
1.  Nick Montgomery		5/4/14 	
1.  Patrick Moore		5/5/14 	
1.  Edmund Dipple		5/6/14 	
1.  Kyle Boorky		5/6/14 	
1.  Olivier Larivain		5/6/14 	
1.  Aaron Valade		5/7/14 	
1.  Jonathan Serafini		5/7/14 	
1.  Jason Nelson	Rackspace	5/8/14 	
1.  Alexander Meng		5/8/14 	
1.  Kyle McGovern	Cerner Innovation Inc	5/8/14 	
1.  Jesse Washburn		5/8/14 	
1.  Ian Blenke		5/9/14 	
1.  Jochen Seeber		5/9/14 	
1.  Florin Stan		5/9/14 	
1.  Bearnard Hibbins		5/12/14 	
1.  Amruta Krishna	Cerner Innovation Inc	5/13/14 	
1.  Daniel Zautner		5/13/14 	
1.  Andrew DuFour		5/13/14 	
1.  David Gil Oliva		5/19/14 	
1.  Emmanuel Sciara		5/20/14 	
1.  Francois Visconte		5/21/14 	
1.  Cyril Scetbon		5/21/14 	
1.  Doug Wilson	CustomInk	4/4/14 	
1.  Meherez Alachheb		5/22/14 	
1.  Ash Wilson	Rackspace	5/22/14 	
1.  Alexey Velikiy		5/21/14 	
1.  Anand Suresh		5/24/14 	
1.  Christoph Krämer		5/26/14 	
1.  Marcus Nilsson		5/27/14 	
1.  Eric Black		5/27/14 	
1.  Michiel Sikkes		5/29/14 	
1.  Miguel Landaeta		5/29/14 	
1.  Claude Ballew Jr		5/29/14 	
1.  Carlos Macasaet		5/29/14 	
1.  Steve Jansen		6/3/14 	
1.  Jake Champlin		6/4/14 	
1.  Alistair Stead	Iniqa UK, Ltd	6/4/14 	
1.  Fahd Sultan		6/4/14 	
1.  Martin Smith III	Rackspace	6/4/14 	
1.  Klaas Jan Wierenga		6/5/14 	
1.  Michael Bumann		6/6/14 	
1.  Grant Hudgens		6/6/14 	
1.  Rob Redpath	World Wide Web Hosting, LLC	6/6/14 	
1.  Benjamin Ahrens		6/9/14 	
1.  Alessio Franceschelli		6/10/14 	
1.  Joseph Bowman		6/11/14 	
1.  William Cody Crawford		6/11/14 	
1.  Ryan Trauntvein		6/12/14 	
1.  Adam Lavin		6/14/14 	
1.  Brett Cave	Jemstep	6/13/14 	
1.  Matt Wrock		6/16/14 	
1.  William Clark		6/17/14 	
1.  Karsten McMinn		6/17/14 	
1.  Alexander Simonov		6/17/14 	
1.  James Coleman		6/18/14 	
1.  Charles Ruhl		6/18/14 	
1.  Pushkar Subhash Raste		6/19/14 	
1.  John Coleman		6/20/14 	
1.  Joshua Rutherford		6/20/14 	
1.  Elijah Buck		6/21/14 	
1.  Nikalai Stakanov		6/22/14 	
1.  Blair Hamilton		6/22/14 	
1.  Jeffrey Goldschrafe		6/24/14 	
1.  Vijay Bheemineni		6/25/14 	
1.  Joshua Benjamin		6/25/14 	
1.  Stafford Brunk		6/25/14 	
1.  Sumit Gupta		6/26/14 	 	
1.  Jan Mara		6/27/14
