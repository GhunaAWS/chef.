#!/bin/sh

cat VERSION
