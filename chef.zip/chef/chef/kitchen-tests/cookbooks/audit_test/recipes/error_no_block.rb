#
# Cookbook Name:: audit_test
# Recipe:: error_no_block
#
# Copyright 2014-2016, The Authors, All Rights Reserved.

control_group "empty control group without block"
