require "chef/chef_fs/file_system/chef_server/acl_entry"

module Chef::ChefFS::FileSystem
  AclEntry = ChefServer::AclEntry
end
