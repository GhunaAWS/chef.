require "chef/chef_fs/file_system/repository/chef_repository_file_system_root_dir"

module Chef::ChefFS::FileSystem
  ChefRepositoryFileSystemRootDir = Repository::ChefRepositoryFileSystemRootDir
end
