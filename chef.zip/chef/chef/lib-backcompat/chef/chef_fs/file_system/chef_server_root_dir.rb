require "chef/chef_fs/file_system/chef_server/chef_server_root_dir"

module Chef::ChefFS::FileSystem
  ChefServerRootDir = ChefServer::ChefServerRootDir
end
