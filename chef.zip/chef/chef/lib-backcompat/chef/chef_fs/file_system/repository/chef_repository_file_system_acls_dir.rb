require "chef/chef_fs/file_system/repository/acls_dir"

module Chef::ChefFS::FileSystem::Repository
  ChefRepositoryFileSystemAclsDir = AclsDir
end
