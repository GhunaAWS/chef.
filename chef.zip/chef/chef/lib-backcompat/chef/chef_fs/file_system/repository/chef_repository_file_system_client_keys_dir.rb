require "chef/chef_fs/file_system/repository/client_keys_dir"

module Chef::ChefFS::FileSystem::Repository
  ChefRepositoryFileSystemClientKeysDir = ClientKeysDir
end
