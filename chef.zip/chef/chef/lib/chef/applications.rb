require "chef/application/client"
require "chef/application/knife"
require "chef/application/solo"
require "chef/application/apply"
